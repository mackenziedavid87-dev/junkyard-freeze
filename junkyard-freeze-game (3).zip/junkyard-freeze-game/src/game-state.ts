/**
 * Shared game state for JUNKYARD FREEZE — David's Meta VR Start Developer
 * Competition 2026 entry (single-player vertical slice).
 *
 * The game, in David's words: a mix of Five Nights at Freddy's, hide and
 * seek, and run-and-gun in an old junkyard. Creatures chase you and can't
 * die — a freeze gun freezes them for a while, then they thaw. Freezing
 * earns points; points buy a better freeze gun. You win by collecting car
 * parts, assembling them in your little garage room, and driving the car out.
 *
 * This file holds the ECS components every game system reads/writes, plus the
 * tuning numbers and layout constants, so there is one place to change them.
 */

import { createComponent, Types } from "@iwsdk/core";

/** Game phases. Stored in GameState.phase. */
export const PHASE_PLAYING = 0;
export const PHASE_WON = 1;
export const PHASE_LOST = 2;

/** How many car parts win the game. */
export const PARTS_TO_WIN = 6;

/** Seconds on the "THE CREATURE GOT YOU!" screen before the run
 * automatically restarts (added 2026-11-11, round 2: David confirmed in
 * VR that a catch just sat on the end screen until he hit reset — the
 * run must never wait for a manual restart). */
export const AUTO_RESTART_SECONDS = 2;

/** Creature height scale (round 3, 2026-11-12: David said the creature
 * is still smaller than the player, which isn't menacing — 1.4x on the
 * new build, whose drive-shaft neck makes it ~1.37 m tall unscaled, so
 * he stands ~1.9 m tall, clearly taller than the player. Applied to
 * each creature's root group in index.ts, so body, neck, eyes and ice
 * block scale together. Speed, freeze/thaw and catch distance are
 * unchanged. Was 1.3 (~1.5 m) in round 2. */
export const CREATURE_SCALE = 1.4;

/** Where the second creature spawns — the far south-east corner, well
 * away from the player start (0, 0, 6) and from creature 1's spawn
 * (0, 0, -3), clear of every car (nearest car 4.3 m away). */
export const CREATURE_SPAWN_2: [number, number, number] = [14, 0, 11];

/** Parts installed before the second creature drops in (round 3,
 * 2026-11-12: David's pacing fix is difficulty, not length — the second
 * creature arrives halfway through the run, after the 3rd of 6 parts). */
export const SECOND_CREATURE_PARTS = 3;

/** Metres a creature walks per footstep clank (round 3: one soft
 * metallic clank per stride, so the clanking tracks how fast it moves). */
export const CREATURE_STEP_LENGTH = 0.55;

/**
 * DAVID'S POINT SYSTEM (set by David, 2026-11-09):
 * - Freeze the monster = 1 point.
 * - Freeze a friend = 1 point (multiplayer only — no friends exist yet).
 * - COMBO = 5 points: freeze your friend AND the monster, and the monster
 *   thaws first and eats your friend. Multiplayer only — see awardCombo()
 *   in game.ts; nothing calls it in this single-player slice.
 * - Installing a car part pays 2 points (rescaled from 25 to match the new
 *   1-point freeze economy, so the 5-point gun upgrade stays earned).
 */
export const POINTS_PER_FREEZE = 1;
export const POINTS_PER_FRIEND_FREEZE = 1;
export const POINTS_PER_COMBO = 5;
export const POINTS_PER_PART = 2;

/** Freeze-gun shop: one upgrade, bought with points. */
export const UPGRADE_COST = 5;
export const FREEZE_SECONDS_MK1 = 5;
export const FREEZE_SECONDS_MK2 = 9;
export const FIRE_COOLDOWN_MK1 = 0.8;
export const FIRE_COOLDOWN_MK2 = 0.45;

/**
 * DAVID'S GUN RULES (set by David, 2026-11-09): the freeze gun only holds
 * TWO safe shots — the two green lights on the gun. A third shot (the red
 * light) backfires and freezes YOU. Each spent shot recharges after 4
 * seconds, so the gun is never permanently empty: the limit stops burst
 * spam, it isn't a lifetime cap — otherwise the single-player game would
 * become unplayable the third time the monster needs freezing.
 */
export const MAGAZINE_SIZE = 2;
export const SHOT_RECHARGE_SECONDS = 4;
/** How long a backfire freezes the player (the creature can catch you). */
export const BACKFIRE_FREEZE_SECONDS = 3;

/** Creature chase speed (m/s). It gets a little faster per part installed. */
export const CREATURE_BASE_SPEED = 1.25;
export const CREATURE_SPEED_PER_PART = 0.12;

/** Seconds at the start of a run before the creature starts hunting. */
export const GRACE_SECONDS = 8;

/** How close the creature has to get to catch the player (meters). */
export const CATCH_DISTANCE = 0.8;

/** Where the player starts, and where the creature starts. */
export const PLAYER_START: [number, number, number] = [0, 0, 6];
/** Dead centre of the yard, down the open passage — visible from the start. */
export const CREATURE_SPAWN: [number, number, number] = [0, 0, -3];

/** The car frame in the garage — drop a part near here to install it. */
export const CAR_FRAME_POS: [number, number, number] = [0, 0, -16.3];
export const INSTALL_RADIUS = 1.6;

/** Cars parked in rows, with gaps between them as passages. Shared by the
 * scene builder (index.ts) and the creature's obstacle map (creature.ts)
 * so the two can never drift apart.
 *
 * Round 2 (2026-11-11): the yard grew ~1.5x (31 x 31 m) so the game
 * lasts longer than a minute — 28 cars in 5 staggered rows, 2 stacked.
 * Rows sit 5 m apart and cars 5 m apart in a row, so the gaps between
 * neighbouring block circles stay ~2 m wide and the creature can still
 * thread the passages. */
export const CAR_SPOTS: Array<{
  x: number;
  z: number;
  rot: number;
  stacked: boolean;
}> = [
  { x: -12.5, z: -13, rot: 0.1, stacked: true },
  { x: -7.5, z: -13, rot: -0.08, stacked: false },
  { x: -2.5, z: -13, rot: 0.05, stacked: false },
  { x: 2.5, z: -13, rot: -0.12, stacked: false },
  { x: 7.5, z: -13, rot: 0.08, stacked: false },
  { x: 12.5, z: -13, rot: -0.06, stacked: false },
  { x: -10, z: -8, rot: -0.05, stacked: false },
  { x: -5, z: -8, rot: 0.12, stacked: false },
  { x: 0, z: -8, rot: -0.1, stacked: false },
  { x: 5, z: -8, rot: 0.06, stacked: false },
  { x: 10, z: -8, rot: -0.07, stacked: false },
  { x: -12.5, z: -3, rot: 0.07, stacked: false },
  { x: -7.5, z: -3, rot: -0.06, stacked: false },
  { x: -2.5, z: -3, rot: 0.1, stacked: false },
  { x: 2.5, z: -3, rot: -0.09, stacked: false },
  { x: 7.5, z: -3, rot: 0.08, stacked: false },
  { x: 12.5, z: -3, rot: -0.05, stacked: false },
  { x: -10, z: 2, rot: -0.11, stacked: false },
  { x: -5, z: 2, rot: 0.06, stacked: false },
  { x: 0, z: 2, rot: -0.07, stacked: false },
  { x: 5, z: 2, rot: 0.09, stacked: false },
  { x: 10, z: 2, rot: -0.04, stacked: false },
  { x: -12.5, z: 7, rot: 0.1, stacked: false },
  { x: -7.5, z: 7, rot: -0.08, stacked: false },
  { x: -2.5, z: 7, rot: 0.05, stacked: false },
  { x: 2.5, z: 7, rot: -0.12, stacked: false },
  { x: 7.5, z: 7, rot: 0.08, stacked: false },
  { x: 12.5, z: 7, rot: 0.06, stacked: true },
];

/**
 * CREATURE OBSTACLE MAP (added 2026-11-10, after David's first playtest:
 * the creature chased in a straight line, ran into a car, and parked
 * there). The creature has no physics body, so it gets a simple
 * ground-plane obstacle map instead: each car is a circle, the garage
 * walls are line segments, the car frame is a circle, and the yard walls
 * are a bounds box. The creature slides along these instead of
 * dead-stopping, and sidesteps when it gets wedged anyway.
 *
 * A car is 2.0 m long x 0.9 m wide, so its half-diagonal is ~1.1 m; the
 * block radius adds the creature's ~0.5 m body (it grew to ~1.9 m tall in
 * round 3, so the body radius went 0.45 -> 0.5 and the block radius
 * 1.5 -> 1.55), so the creature walks around the cars instead of through
 * them. The gaps between neighbouring cars stay ~1.9 m wide, so the
 * creature can still thread the passages.
 */
export const CREATURE_BODY_RADIUS = 0.5;
export const CAR_BLOCK_RADIUS = 1.55;
/** The car frame in the garage, as a circle the creature walks around. */
export const CAR_FRAME_BLOCK_RADIUS = 1.25;
/** Garage walls as ground-plane segments (back, west, east — south is open).
 * The garage moved to the new north edge in round 2 (back wall z=-18.6). */
export const GARAGE_WALL_SEGMENTS: Array<{
  x1: number;
  z1: number;
  x2: number;
  z2: number;
}> = [
  { x1: -2.2, z1: -18.6, x2: 2.2, z2: -18.6 }, // back
  { x1: -2.2, z1: -18.6, x2: -2.2, z2: -14.7 }, // west
  { x1: 2.2, z1: -18.6, x2: 2.2, z2: -14.7 }, // east
];
/** Yard bounds the creature stays inside (inner wall faces minus body).
 * Round 2: ~1.5x bigger, 31 x 31 m (was 21 x 21 m). */
export const YARD_BOUNDS = { minX: -15.5, maxX: 15.5, minZ: -18.5, maxZ: 12.5 };
/** Seconds barely moving while chasing before the creature sidesteps. */
export const CREATURE_STUCK_SECONDS = 2;
/** How long one sidestep lasts once the creature is unsticking itself. */
export const CREATURE_UNSTICK_SECONDS = 1.2;

/**
 * One entity in the scene carries this — the single source of truth for the
 * run. Systems read it with `entity.getValue(GameState, 'points')` and write
 * it with `entity.setValue(GameState, 'points', value)`.
 */
export const GameState = createComponent("GameState", {
  /** PHASE_PLAYING / PHASE_WON / PHASE_LOST. */
  phase: { type: Types.Int32, default: PHASE_PLAYING },
  /** Points earned this run. */
  points: { type: Types.Int32, default: 0 },
  /** Car parts installed so far (0..PARTS_TO_WIN). */
  partsCollected: { type: Types.Int32, default: 0 },
  /** Freeze-gun level: 1 = starter, 2 = upgraded. */
  gunLevel: { type: Types.Int32, default: 1 },
  /** How long a freeze lasts, in seconds (depends on gun level). */
  freezeDuration: { type: Types.Float32, default: FREEZE_SECONDS_MK1 },
  /** Game time before the gun can fire again (anti-spam). */
  fireCooldownUntil: { type: Types.Float32, default: 0 },
  /** Safe shots left in the magazine (0..MAGAZINE_SIZE). */
  shotsReady: { type: Types.Int32, default: MAGAZINE_SIZE },
  /** Game time when the next spent shot recharges (0 = none pending). */
  nextRechargeAt: { type: Types.Float32, default: 0 },
  /** Game time until the player's backfire self-freeze ends (0 = not frozen). */
  playerFrozenUntil: { type: Types.Float32, default: 0 },
  /** Game time when the creature last caught the player and the run
   *  went to the lose screen (0 = never this run). The run auto-restarts
   *  AUTO_RESTART_SECONDS after this — see GameSystem.update(). Replaces
   *  the old respawn design (2026-11-11 round 2): David confirmed in VR
   *  that a catch just sat on the end screen until he hit reset, so a
   *  catch now shows "THE CREATURE GOT YOU!" briefly and restarts the
   *  run on its own. */
  lostAt: { type: Types.Float32, default: 0 },
  /** How many times the creature has caught the player this run. */
  catches: { type: Types.Int32, default: 0 },
});

/**
 * Tag + data for a creature. The creatures are built from old car parts
 * (see makeCreature in index.ts): drive-shaft legs, rotor feet, a motor
 * for a body, a bumper mouth, and headlight eyes — with a drive-shaft
 * neck holding the head up over the body (round 3, 2026-11-12), and the
 * second creature has wrench arms (a wrench with a hammer on the end on
 * the right, two wrenches on the left, little wrenches for fingers).
 *
 * Round 3 also added the second creature: it spawns once
 * SECOND_CREATURE_PARTS are installed (spawnAtParts), and stays hidden
 * until then (spawned). Both creatures chase with the same rules.
 */
export const Creature = createComponent("Creature", {
  /** Game time when the creature thaws (0 = not frozen). */
  frozenUntil: { type: Types.Float32, default: 0 },
  /** Game time when the creature starts hunting (grace period at run start). */
  activeAfter: { type: Types.Float32, default: 8 },
  /** Parts installed before this creature spawns (0 = from run start). */
  spawnAtParts: { type: Types.Int32, default: 0 },
  /** True once this creature has spawned this run. */
  spawned: { type: Types.Boolean, default: true },
  /** Where this creature spawns (restart puts it back here). */
  homeX: { type: Types.Float32, default: 0 },
  homeZ: { type: Types.Float32, default: 0 },
  /** Footstep clanks this run (debug/probe counter). */
  steps: { type: Types.Int32, default: 0 },
  /** Child entity carrying this creature's positional footstep AudioSource
   * (clank.wav, set in index.ts) — null until the scene is built. */
  stepAudio: { type: Types.Entity, default: null },
});

/** Tag + data for a car part the player can carry to the garage. */
export const CarPart = createComponent("CarPart", {
  /** 0 = engine, 1 = wheel, 2 = door, 3 = battery, 4 = headlight,
   *  5 = steering wheel (headlight + steering wheel added 2026-11-11,
   *  round 2 — six parts to win, so the game lasts longer than a minute). */
  partId: { type: Types.Int32, default: 0 },
  /** True once the part has been installed on the car frame. */
  installed: { type: Types.Boolean, default: false },
  /** Where the part starts the run (so restart can put it back). */
  homeX: { type: Types.Float32, default: 0 },
  homeY: { type: Types.Float32, default: 0.6 },
  homeZ: { type: Types.Float32, default: 0 },
});

/**
 * Tag for the glowing shape on the car frame that appears when its part is
 * installed. slotIndex matches the CarPart.partId it represents.
 */
export const CarSlot = createComponent("CarSlot", {
  slotIndex: { type: Types.Int32, default: 0 },
});
