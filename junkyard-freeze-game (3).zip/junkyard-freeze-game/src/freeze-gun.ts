/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  AudioUtils,
  BoxGeometry,
  createSystem,
  CylinderGeometry,
  Group,
  Mesh,
  MeshBasicMaterial,
  PanelUI,
  Pressed,
  Quaternion,
  Raycaster,
  SphereGeometry,
  Vector2,
  Vector3,
  VisibilityState,
} from "@iwsdk/core";
import type { Entity, Object3D } from "@iwsdk/core";

import { GameSystem } from "./game.js";
import { Creature, MAGAZINE_SIZE } from "./game-state.js";

/** Gun light colours: lit vs dim. */
const GREEN_LIT = 0x2bff5e;
const GREEN_DIM = 0x0e2f18;
const RED_LIT = 0xff2a33;
const RED_DIM = 0x330e10;

/**
 * BUILDING BLOCK — the freeze gun.
 *
 * Point the controller ray at the creature and pull the trigger (or click
 * it with the mouse in the browser preview). In XR the ray's `Pressed` tag
 * on the creature is the shot — no manual raycasting, exactly how the
 * starter's chime worked when you clicked the robot. In the browser
 * preview the engine's canvas pointer path does not deliver clicks (see
 * the preview-click handler in init()), so a pointerdown on the canvas
 * raycasts from the camera and fires when the creature is the nearest
 * thing under the cursor. A hit freezes the creature for the gun's freeze
 * time (5s stock, 9s upgraded), pays 1 point, and flashes a cyan beam
 * from the gun hand to the creature. The creature can never die; it
 * always thaws. Round 2 (2026-11-11): UI panels and the gun mesh itself
 * are see-through to that raycast — they used to swallow clicks (the
 * welcome panel stands right between the player and the yard at the
 * start of a run); only real occluders — cars, walls, ground, the car
 * frame — block the shot.
 *
 * DAVID'S GUN RULES (2026-11-09): the gun only holds TWO safe shots. The
 * gun shows them as two green lights; the third light is red. Fire while
 * both green lights are out and the shot backfires — a red beam flashes
 * back at you and YOU freeze for 3 seconds while the creature closes in.
 * Spent shots recharge one at a time, 4 seconds each, so the gun is never
 * permanently empty.
 */
export class FreezeGunSystem extends createSystem({
  /** All creatures (for the browser-preview click handler). */
  creatures: { required: [Creature] },
  /** Fires when the trigger is pulled while the ray is on the creature. */
  creaturePressed: { required: [Creature, Pressed] },
  /** UI panels (for the browser-preview click handler — panel meshes
   * must never block a shot; see onPreviewClick). */
  panels: { required: [PanelUI] },
}) {
  private beam!: Mesh;
  private beamMat!: MeshBasicMaterial;
  private beamHideAt = 0;
  /** Latest engine clock, kept fresh by update(). */
  private lastTime = 0;
  private origin!: Vector3;
  private target!: Vector3;
  private mid!: Vector3;
  private dir!: Vector3;
  private up!: Vector3;
  private quat!: Quaternion;
  /** The gun mesh, riding on the right controller (camera in preview). */
  private gun!: Group;
  /** Light materials, in order: green, green, red. */
  private lightMats: MeshBasicMaterial[] = [];
  /** Shots shown on the lights last frame — only recolour on change. */
  private lastShots = -1;
  /** Scratch raycaster + NDC for the browser-preview click handler. */
  private previewRaycaster!: Raycaster;
  private previewNdc!: Vector2;

  init() {
    this.origin = new Vector3();
    this.target = new Vector3();
    this.mid = new Vector3();
    this.dir = new Vector3();
    this.up = new Vector3(0, 1, 0);
    this.quat = new Quaternion();

    // A thin rod, stretched between gun and target on each shot. Cylinder
    // geometry runs along Y, so it is aimed by rotating Y onto the shot
    // direction and scaling Y to the shot distance.
    this.beamMat = new MeshBasicMaterial({
      color: 0x7fe7ff,
      transparent: true,
      opacity: 0.9,
    });
    this.beam = new Mesh(new CylinderGeometry(0.025, 0.025, 1, 8), this.beamMat);
    this.beam.visible = false;
    this.world.createTransformEntity(this.beam);

    // The gun itself: a small body and barrel, with DAVID'S LIGHTS on top —
    // two green for the safe shots, one red for the backfire shot. It rides
    // on the right controller in XR, and on the camera in the browser
    // preview (where there is no controller to hold it).
    this.gun = new Group();
    this.gun.name = "freeze-gun";
    const bodyMat = new MeshBasicMaterial({ color: 0x2a2a2e });
    const body = new Mesh(new BoxGeometry(0.07, 0.09, 0.24), bodyMat);
    this.gun.add(body);
    const barrel = new Mesh(new CylinderGeometry(0.02, 0.02, 0.14, 10), bodyMat);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.01, -0.17);
    this.gun.add(barrel);
    const lightPositions: Array<[number, number, number]> = [
      [-0.024, 0.055, 0.05],
      [0, 0.055, 0.05],
      [0.024, 0.055, 0.05],
    ];
    for (let i = 0; i < 3; i++) {
      const mat = new MeshBasicMaterial({ color: GREEN_DIM });
      const light = new Mesh(new SphereGeometry(0.013, 10, 8), mat);
      light.position.set(...lightPositions[i]);
      this.gun.add(light);
      this.lightMats.push(mat);
    }
    this.attachGun();
    // The XR input rig is rebuilt when a session starts, so re-attach the
    // gun on every visibility change (same pattern as the ray system).
    this.cleanupFuncs.push(
      this.world.visibilityState.subscribe(() => this.attachGun()),
    );

    this.queries.creaturePressed.subscribe("qualify", (entity) => {
      this.shoot(entity);
    });

    // BROWSER PREVIEW CLICK (added 2026-11-10, after David's first
    // playtest: mouse click does not fire the gun in the browser preview).
    // The engine's canvas pointer path (RayInteractable -> Pressed) does
    // not deliver clicks on the creature in the preview — verified twice
    // in a headless probe (even the HUD RESTART button click doesn't
    // register) and by David's live report — so the preview gets an
    // explicit click handler: a camera raycast on pointerdown that fires
    // only when the creature is the nearest thing under the cursor.
    // This is a deliberate, narrow exception to the "don't use a manual
    // Raycaster" rule: the Interactable path is kept for XR (and it works
    // there — the trigger fired the gun in the emulator on 2026-11-09),
    // and this handler is NonImmersive-only. It cannot double-fire with
    // the Pressed path: the engine's canvas listener runs first (it was
    // registered at world creation), so if Pressed is already on the
    // creature this click is the engine's and we skip it; and the 0.8s
    // fire cooldown in attemptShot() blocks any second shot anyway.
    this.previewRaycaster = new Raycaster();
    this.previewNdc = new Vector2();
    const canvas = this.renderer.domElement;
    const onPreviewPointerDown = (event: PointerEvent) => {
      this.onPreviewClick(event);
    };
    canvas.addEventListener("pointerdown", onPreviewPointerDown);
    this.cleanupFuncs.push(() =>
      canvas.removeEventListener("pointerdown", onPreviewPointerDown),
    );
  }

  update(_delta: number, time: number) {
    this.lastTime = time;
    if (this.beam.visible && time >= this.beamHideAt) {
      this.beam.visible = false;
    }

    // Gun lights: green light i burns while shot i is ready; the red light
    // burns while the magazine is empty — that is the backfire shot.
    // Don't use the red one.
    const game = this.world.getSystem(GameSystem);
    const shots = game?.shotsReady() ?? MAGAZINE_SIZE;
    if (shots !== this.lastShots) {
      this.lastShots = shots;
      for (let i = 0; i < 2; i++) {
        this.lightMats[i].color.setHex(shots > i ? GREEN_LIT : GREEN_DIM);
      }
      this.lightMats[2].color.setHex(shots === 0 ? RED_LIT : RED_DIM);
    }
  }

  /** Parent the gun to the right controller in XR, to the camera in preview. */
  private attachGun() {
    if (this.world.visibilityState.value === VisibilityState.NonImmersive) {
      this.camera.add(this.gun);
      this.gun.position.set(0.3, -0.24, -0.6);
      this.gun.rotation.set(0, 0, 0);
    } else {
      this.player.gripSpaces.right.add(this.gun);
      this.gun.position.set(0, 0.03, -0.02);
      this.gun.rotation.set(0, 0, 0);
    }
  }

  /** All creature entities (this slice has two since round 3). */
  private creatureEntities(): Entity[] {
    return [...this.queries.creatures.entities];
  }

  /** Mouse click in the browser preview: fire when a creature is the
   * nearest thing under the cursor. NonImmersive only; XR uses Pressed.
   *
   * Round 2 (2026-11-11): David still reports clicks not firing in his
   * browser preview, although the headless probe scored +1 and the gun
   * works in VR. Two real blockers were in this handler: (1) the
   * welcome panel stands between the player and the yard at the start
   * of a run, and the game HUD stands at the garage — their 3D meshes
   * are the nearest raycast hit, so a click on the creature behind one
   * swallowed the shot; (2) the gun itself rides on the camera in the
   * preview, so a click through the gun mesh was swallowed the same
   * way. Panels and the gun are now skipped — only a real occluder
   * (car, wall, ground, car frame) blocks the shot. Cars/walls still
   * block it, as they should: the creature has to be in the open.
   *
   * Round 3 (2026-11-12): the handler now checks every creature, not
   * just the first — the second creature is a valid target too. */
  private onPreviewClick(event: PointerEvent) {
    if (event.button !== 0) {
      return;
    }
    if (this.world.visibilityState.value !== VisibilityState.NonImmersive) {
      return;
    }
    const creatures = this.creatureEntities().filter((c) => c.object3D);
    if (creatures.length === 0) {
      return;
    }
    // The engine's Pressed path is handling this click — don't double-fire.
    for (const creature of creatures) {
      if (creature.hasComponent(Pressed)) {
        return;
      }
    }
    const canvas = this.renderer.domElement;
    const rect = canvas.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) {
      return;
    }
    this.previewNdc.set(
      ((event.clientX - rect.left) / rect.width) * 2 - 1,
      -((event.clientY - rect.top) / rect.height) * 2 + 1,
    );
    this.previewRaycaster.setFromCamera(this.previewNdc, this.camera);
    const hits = this.previewRaycaster.intersectObject(this.scene, true);
    if (hits.length === 0) {
      return;
    }
    // Walk the hits nearest-first. A creature fires the gun; a UI panel
    // or the gun mesh itself is see-through to the shot; anything else
    // (car, wall, ground, car frame) is a real occluder and blocks it.
    const creatureRoots = new Map<Object3D, Entity>();
    for (const creature of creatures) {
      creatureRoots.set(creature.object3D!, creature);
    }
    const panelRoots = new Set<Object3D>();
    for (const panel of this.queries.panels.entities) {
      if (panel.object3D) {
        panelRoots.add(panel.object3D);
      }
    }
    for (const hit of hits) {
      let obj: Object3D | null = hit.object;
      let hitCreature: Entity | null = null;
      let isPanel = false;
      let isGun = false;
      while (obj) {
        const match = creatureRoots.get(obj);
        if (match) {
          hitCreature = match;
          break;
        }
        if (panelRoots.has(obj)) {
          isPanel = true;
          break;
        }
        if (obj === this.gun) {
          isGun = true;
          break;
        }
        obj = obj.parent;
      }
      if (hitCreature) {
        this.shoot(hitCreature);
        return;
      }
      if (isPanel || isGun) {
        continue;
      }
      // A real occluder is in front of the creature — no shot.
      return;
    }
  }

  private shoot(creature: Entity) {
    const game = this.world.getSystem(GameSystem);
    if (!game) {
      return;
    }
    const result = game.attemptShot();
    if (result === "fire") {
      game.freezeCreature(creature);
      AudioUtils.play(creature);
      creature.object3D?.getWorldPosition(this.target);
      this.showBeam(this.target, 0x7fe7ff);
    } else if (result === "backfire") {
      // The red light: the shot hit YOU instead. Flash a red beam back at
      // the player's head so the backfire reads instantly.
      this.player.head.getWorldPosition(this.target);
      this.showBeam(this.target, 0xff2a33);
    }
    // "blocked" (cooling down, frozen, or not playing) — nothing happens.
  }

  private showBeam(target: Vector3, color: number) {
    // In the headset the beam leaves the right hand; in the browser preview
    // (no controllers) it leaves the camera.
    if (this.world.visibilityState.value === VisibilityState.NonImmersive) {
      this.camera.getWorldPosition(this.origin);
    } else {
      this.player.gripSpaces.right.getWorldPosition(this.origin);
    }
    this.dir.subVectors(target, this.origin);
    const distance = this.dir.length();
    if (distance < 0.05) {
      return;
    }
    this.dir.divideScalar(distance);
    this.mid.addVectors(this.origin, target).multiplyScalar(0.5);
    this.quat.setFromUnitVectors(this.up, this.dir);
    this.beamMat.color.setHex(color);
    this.beam.position.copy(this.mid);
    this.beam.quaternion.copy(this.quat);
    this.beam.scale.set(1, distance, 1);
    this.beam.visible = true;
    this.beamHideAt = this.lastTime + 0.15;
  }
}
