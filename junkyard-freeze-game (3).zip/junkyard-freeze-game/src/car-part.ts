/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { createSystem, Grabbed, Vector3 } from "@iwsdk/core";
import type { Entity } from "@iwsdk/core";

import { GameSystem } from "./game.js";
import {
  CAR_FRAME_POS,
  CarPart,
  GameState,
  INSTALL_RADIUS,
  PHASE_PLAYING,
} from "./game-state.js";

/**
 * The car parts. Each one is a `DistanceGrabbable`: point the ray at it and
 * hold the trigger (or hold the mouse button on it in the browser preview)
 * and it flies to your hand — carry it back to the garage and let go over
 * the car frame to install it.
 *
 * Idle parts bob gently so they are easy to spot in the dusk. A part that is
 * let go inside the install zone around the car frame snaps onto the car.
 */
export class CarPartSystem extends createSystem({
  parts: { required: [CarPart] },
  heldParts: { required: [CarPart, Grabbed] },
  game: { required: [GameState] },
}) {
  private framePos!: Vector3;
  private partPos!: Vector3;

  init() {
    this.framePos = new Vector3(...CAR_FRAME_POS);
    this.partPos = new Vector3();

    // Released = let go of. If it lands near the car frame, it is installed.
    this.queries.heldParts.subscribe("disqualify", (entity) => {
      this.onPartReleased(entity);
    });
  }

  update(_delta: number, time: number) {
    for (const part of this.queries.parts.entities) {
      if (part.getValue(CarPart, "installed")) {
        continue;
      }
      if (part.hasComponent(Grabbed)) {
        continue; // the grab system owns the transform while it is held
      }
      const obj = part.object3D;
      if (!obj) {
        continue;
      }
      const homeY = part.getValue(CarPart, "homeY") ?? 0.6;
      const partId = part.getValue(CarPart, "partId") ?? 0;
      obj.position.y = homeY + Math.sin(time * 1.5 + partId * 1.7) * 0.05;
    }
  }

  private onPartReleased(part: Entity) {
    const game = this.world.getSystem(GameSystem);
    if (!game || game.phase() !== PHASE_PLAYING) {
      return;
    }
    if (part.getValue(CarPart, "installed")) {
      return;
    }
    part.object3D?.getWorldPosition(this.partPos);
    const dx = this.partPos.x - this.framePos.x;
    const dz = this.partPos.z - this.framePos.z;
    if (Math.sqrt(dx * dx + dz * dz) <= INSTALL_RADIUS) {
      game.installPart(part);
    }
  }
}
