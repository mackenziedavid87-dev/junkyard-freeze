/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  AudioUtils,
  createSystem,
  eq,
  InputComponent,
  PanelDocument,
  PanelUI,
  StatefulGamepad,
  UIKit,
  UIKitDocument,
} from "@iwsdk/core";

import { GameSystem } from "./game.js";
import { BackgroundMusic } from "./music.js";

const HUD_INTERVAL = 0.1; // seconds between HUD refreshes

/**
 * BUILDING BLOCK — full controller input mapping.
 *
 * Reads both XR controller gamepads every frame and gives the inputs a
 * handler in JUNKYARD FREEZE:
 *
 * | Input                | Handler                                       |
 * | -------------------- | --------------------------------------------- |
 * | A (right)            | buy the freeze-gun upgrade (30 pts)         |
 * | B (right)            | restart the run                             |
 * | Y (left)             | restart the run                             |
 * | Trigger (either)     | fire the freeze gun (see src/freeze-gun.ts) |
 * | Grip / squeeze (left)| toggle the background music                   |
 * | Thumbstick (left)    | walk (locomotion glides)                    |
 * | Thumbstick (right)   | snap-turn (locomotion)                      |
 *
 * The HUD panel mirrors live button / trigger / grip / thumbstick values so
 * you can confirm input is arriving even when a handler does nothing visible.
 * (The starter's demo-cube handlers lived here; the cube is gone, the game
 * actions took its place. The HUD mirror itself is unchanged.)
 */
export class ControllerInputSystem extends createSystem({
  hud: {
    required: [PanelUI, PanelDocument],
    where: [eq(PanelUI, "config", "./ui/input-hud.uikitml")],
  },
  music: { required: [BackgroundMusic] },
}) {
  private hudEls: Record<string, UIKit.Text> = {};
  private hudCache: Record<string, string> = {};
  private lastHud = 0;

  init() {
    this.queries.hud.subscribe("qualify", (entity) => {
      const doc = PanelDocument.data.document[entity.index] as UIKitDocument;
      if (!doc) {
        return;
      }
      for (const id of [
        "l-x",
        "l-y",
        "l-trigger",
        "l-grip",
        "l-stick",
        "r-a",
        "r-b",
        "r-trigger",
        "r-grip",
        "r-stick",
      ]) {
        const el = doc.getElementById(id) as UIKit.Text | null;
        if (el) {
          this.hudEls[id] = el;
        }
      }
    });
  }

  update(_delta: number, time: number) {
    const left = this.input.xr.gamepads.left;
    const right = this.input.xr.gamepads.right;

    this.applyGameActions(left, right);
    this.applyMusicToggle(left);

    if (time - this.lastHud >= HUD_INTERVAL) {
      this.lastHud = time;
      this.updateHud(left, right);
    }
  }

  private applyGameActions(
    left: StatefulGamepad | undefined,
    right: StatefulGamepad | undefined,
  ) {
    const game = this.world.getSystem(GameSystem);
    if (!game) {
      return;
    }
    // A (right): buy the freeze-gun upgrade.
    if (right?.getButtonDown(InputComponent.A_Button)) {
      game.tryUpgrade();
    }
    // B (right) or Y (left): restart the run.
    if (
      right?.getButtonDown(InputComponent.B_Button) ||
      left?.getButtonDown(InputComponent.Y_Button)
    ) {
      game.restart();
    }
  }

  /** Grip / squeeze on the left controller mutes and unmutes the soundtrack. */
  private applyMusicToggle(left: StatefulGamepad | undefined) {
    if (!left?.getButtonDown(InputComponent.Squeeze)) {
      return;
    }
    for (const entity of this.queries.music.entities) {
      if (AudioUtils.isPlaying(entity)) {
        AudioUtils.pause(entity, 0.3);
      } else {
        AudioUtils.play(entity, 0.6);
      }
    }
  }

  private updateHud(
    left: StatefulGamepad | undefined,
    right: StatefulGamepad | undefined,
  ) {
    this.setHud("l-x", `X  ${btn(left?.getButtonPressed(InputComponent.X_Button))}`);
    this.setHud("l-y", `Y  ${btn(left?.getButtonPressed(InputComponent.Y_Button))}`);
    this.setHud("l-trigger", `Trig  ${val(left?.getButtonValue(InputComponent.Trigger))}`);
    this.setHud("l-grip", `Grip  ${btn(left?.getButtonPressed(InputComponent.Squeeze))}`);
    this.setHud("l-stick", `Stick  ${stick(left?.getAxesValues(InputComponent.Thumbstick))}`);

    this.setHud("r-a", `A  ${btn(right?.getButtonPressed(InputComponent.A_Button))}`);
    this.setHud("r-b", `B  ${btn(right?.getButtonPressed(InputComponent.B_Button))}`);
    this.setHud("r-trigger", `Trig  ${val(right?.getButtonValue(InputComponent.Trigger))}`);
    this.setHud("r-grip", `Grip  ${btn(right?.getButtonPressed(InputComponent.Squeeze))}`);
    this.setHud("r-stick", `Stick  ${stick(right?.getAxesValues(InputComponent.Thumbstick))}`);
  }

  private setHud(id: string, text: string) {
    if (this.hudCache[id] === text) {
      return;
    }
    this.hudCache[id] = text;
    this.hudEls[id]?.setProperties({ text });
  }
}

function btn(pressed: boolean | undefined): string {
  return pressed ? "ON" : "off";
}

function val(value: number | undefined): string {
  return (value ?? 0).toFixed(2);
}

function stick(axes: { x: number; y: number } | undefined): string {
  if (!axes) {
    return "0.00, 0.00";
  }
  return `${axes.x.toFixed(2)}, ${axes.y.toFixed(2)}`;
}
