/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  AudioUtils,
  createSystem,
  Grabbed,
  GrabSystem,
  Hovered,
  LocomotionSystem,
  Pressed,
  SlideSystem,
  TeleportSystem,
  TurnSystem,
  Vector3,
} from "@iwsdk/core";
import type { Entity } from "@iwsdk/core";

import {
  AUTO_RESTART_SECONDS,
  BACKFIRE_FREEZE_SECONDS,
  CarPart,
  CarSlot,
  CREATURE_SPAWN,
  Creature,
  FIRE_COOLDOWN_MK1,
  FIRE_COOLDOWN_MK2,
  FREEZE_SECONDS_MK1,
  FREEZE_SECONDS_MK2,
  GameState,
  GRACE_SECONDS,
  MAGAZINE_SIZE,
  PARTS_TO_WIN,
  PHASE_LOST,
  PHASE_PLAYING,
  PHASE_WON,
  PLAYER_START,
  POINTS_PER_COMBO,
  POINTS_PER_FREEZE,
  POINTS_PER_PART,
  SHOT_RECHARGE_SECONDS,
  UPGRADE_COST,
} from "./game-state.js";

/**
 * The brain of JUNKYARD FREEZE. It owns the GameState component and is the
 * one place that changes it — other systems (freeze gun, car parts, creature,
 * HUD, controller input) call these methods instead of poking at the numbers
 * themselves.
 *
 * Other systems reach it with `this.world.getSystem(GameSystem)`.
 */
export class GameSystem extends createSystem({
  game: { required: [GameState] },
  parts: { required: [CarPart] },
  creatures: { required: [Creature] },
  slots: { required: [CarSlot] },
}) {
  /** Latest game time, kept fresh by update() for the fire cooldown. */
  private lastTime = 0;
  private playerStart!: Vector3;
  private creatureSpawn!: Vector3;
  /** Scratch vector for the debug handle's player position. */
  private debugPos!: Vector3;
  /** True while the walk/turn/teleport systems are stopped for a backfire. */
  private locomotionPaused = false;

  init() {
    this.playerStart = new Vector3(...PLAYER_START);
    this.creatureSpawn = new Vector3(...CREATURE_SPAWN);
    this.debugPos = new Vector3();
    // Playtest debug handle (browser console + automated probes):
    // window.__jf.state() reports the live run — phase, points, shots,
    // parts collected / parts in the yard, both creatures' positions
    // (spawned, frozen, hovered/pressed, footstep count) and the player
    // position. window.__jf.restart() restarts the run (same as the HUD
    // RESTART button). window.__jf.installPart(id) installs part id 0-5
    // through the real install path (same code the garage slot calls) —
    // a debug hook for verifying the win after the 6th install without a
    // headset. window.__jf.shootCreature(i) fires a shot at creature i
    // (0 = first, 1 = second) through the real shot path — attemptShot()
    // then freezeCreature() — the same two calls the freeze gun's
    // Pressed/click handlers make; a debug hook for verifying a freeze
    // pays +1 point when the emulator's trigger delivery can't be used.
    // Read-only apart from restart/installPart/shootCreature; safe to
    // leave in.
    if (typeof window !== "undefined") {
      (window as unknown as { __jf?: unknown }).__jf = {
        state: () => this.debugState(),
        restart: () => this.restart(),
        installPart: (id: number) => {
          for (const part of this.queries.parts.entities) {
            if ((part.getValue(CarPart, "partId") ?? -1) === id) {
              this.installPart(part);
              return;
            }
          }
        },
        shootCreature: (idx: number) => {
          const creatures = [...this.queries.creatures.entities];
          const target = creatures[idx];
          if (!target) {
            return false;
          }
          if (this.attemptShot() !== "fire") {
            return false;
          }
          return this.freezeCreature(target);
        },
      };
    }
  }

  /** Live snapshot for window.__jf.state() (see init). */
  private debugState(): {
    phase: number;
    points: number;
    shots: number;
    parts: number;
    partsTotal: number;
    time: number;
    creature: {
      x: number;
      z: number;
      frozen: boolean;
      hovered: boolean;
      pressed: boolean;
    } | null;
    creatures: Array<{
      x: number;
      z: number;
      frozen: boolean;
      hovered: boolean;
      pressed: boolean;
      spawned: boolean;
      steps: number;
    }>;
    player: { x: number; z: number };
  } {
    const game = this.gameEntity();
    let creature: {
      x: number;
      z: number;
      frozen: boolean;
      hovered: boolean;
      pressed: boolean;
    } | null = null;
    const creatures: Array<{
      x: number;
      z: number;
      frozen: boolean;
      hovered: boolean;
      pressed: boolean;
      spawned: boolean;
      steps: number;
    }> = [];
    for (const c of this.queries.creatures.entities) {
      const obj = c.object3D;
      const entry = {
        x: obj ? obj.position.x : 0,
        z: obj ? obj.position.z : 0,
        frozen: (c.getValue(Creature, "frozenUntil") ?? 0) > this.lastTime,
        hovered: c.hasComponent(Hovered),
        pressed: c.hasComponent(Pressed),
        spawned: c.getValue(Creature, "spawned") ?? true,
        steps: c.getValue(Creature, "steps") ?? 0,
      };
      creatures.push(entry);
      if (!creature) {
        creature = {
          x: entry.x,
          z: entry.z,
          frozen: entry.frozen,
          hovered: entry.hovered,
          pressed: entry.pressed,
        };
      }
    }
    this.player.head.getWorldPosition(this.debugPos);
    return {
      phase: this.phase(),
      points: this.points(),
      shots: this.shotsReady(),
      parts: game ? (game.getValue(GameState, "partsCollected") ?? 0) : 0,
      partsTotal: this.queries.parts.entities.size,
      time: this.lastTime,
      creature,
      creatures,
      player: { x: this.debugPos.x, z: this.debugPos.z },
    };
  }

  update(_delta: number, time: number) {
    this.lastTime = time;
    const game = this.gameEntity();
    if (!game) {
      return;
    }

    // Shot recharge: one spent shot comes back every SHOT_RECHARGE_SECONDS
    // until the magazine is full again.
    const nextRecharge = game.getValue(GameState, "nextRechargeAt") ?? 0;
    if (nextRecharge > 0 && time >= nextRecharge) {
      const shots = game.getValue(GameState, "shotsReady") ?? MAGAZINE_SIZE;
      if (shots < MAGAZINE_SIZE) {
        const refilled = shots + 1;
        game.setValue(GameState, "shotsReady", refilled);
        game.setValue(
          GameState,
          "nextRechargeAt",
          refilled < MAGAZINE_SIZE ? time + SHOT_RECHARGE_SECONDS : 0,
        );
      } else {
        game.setValue(GameState, "nextRechargeAt", 0);
      }
    }

    // Backfire self-freeze: pin the player's feet while frozen, so the
    // creature can close in. Locomotion comes back the moment the freeze ends
    // (or the run ends).
    const playerFrozen =
      this.phase() === PHASE_PLAYING &&
      time < (game.getValue(GameState, "playerFrozenUntil") ?? 0);
    this.setLocomotionPaused(playerFrozen);

    // Caught: the run shows "THE CREATURE GOT YOU!" for a couple of
    // seconds, then restarts itself — it must never sit on the lose
    // screen waiting for a manual restart (David's VR playtest,
    // 2026-11-11). The manual RESTART button / B / Y still work too;
    // they just usually won't be needed.
    if (this.phase() === PHASE_LOST) {
      const lostAt = game.getValue(GameState, "lostAt") ?? 0;
      if (lostAt > 0 && time >= lostAt + AUTO_RESTART_SECONDS) {
        this.restart();
      }
    }
  }

  /** Stop/start the walk/turn/teleport systems while the player is frozen. */
  private setLocomotionPaused(paused: boolean) {
    if (paused === this.locomotionPaused) {
      return;
    }
    this.locomotionPaused = paused;
    for (const system of [
      this.world.getSystem(SlideSystem),
      this.world.getSystem(TurnSystem),
      this.world.getSystem(TeleportSystem),
    ]) {
      if (!system) {
        continue;
      }
      if (paused) {
        system.stop();
      } else {
        system.play();
      }
    }
  }

  /** The single GameState entity (index.ts creates exactly one). */
  gameEntity(): Entity | null {
    for (const entity of this.queries.game.entities) {
      return entity;
    }
    return null;
  }

  phase(): number {
    const game = this.gameEntity();
    return game ? (game.getValue(GameState, "phase") ?? PHASE_PLAYING) : PHASE_PLAYING;
  }

  points(): number {
    const game = this.gameEntity();
    return game ? (game.getValue(GameState, "points") ?? 0) : 0;
  }

  addPoints(amount: number) {
    const game = this.gameEntity();
    if (!game) {
      return;
    }
    game.setValue(GameState, "points", this.points() + amount);
  }

  /** Safe shots left in the magazine (0..MAGAZINE_SIZE). */
  shotsReady(): number {
    const game = this.gameEntity();
    return game
      ? (game.getValue(GameState, "shotsReady") ?? MAGAZINE_SIZE)
      : MAGAZINE_SIZE;
  }

  /** True while the player's backfire self-freeze is running. */
  playerFrozen(): boolean {
    const game = this.gameEntity();
    return (
      !!game &&
      this.lastTime < (game.getValue(GameState, "playerFrozenUntil") ?? 0)
    );
  }

  /** True when the gun may fire right now (playing, and past the cooldown). */
  canFire(): boolean {
    const game = this.gameEntity();
    if (!game || this.phase() !== PHASE_PLAYING) {
      return false;
    }
    return this.lastTime >= (game.getValue(GameState, "fireCooldownUntil") ?? 0);
  }

  /** Start the fire cooldown after a shot. */
  recordShot() {
    const game = this.gameEntity();
    if (!game) {
      return;
    }
    const level = game.getValue(GameState, "gunLevel") ?? 1;
    const cooldown = level >= 2 ? FIRE_COOLDOWN_MK2 : FIRE_COOLDOWN_MK1;
    game.setValue(GameState, "fireCooldownUntil", this.lastTime + cooldown);
  }

  /**
   * Try to fire the freeze gun. Returns 'fire' when a safe shot went out,
   * 'backfire' when the magazine was empty and the shot froze the player
   * instead, and 'blocked' when the gun can't shoot right now (cooling
   * down, player frozen, or not playing). The caller owns the shot once
   * this returns 'fire' — it freezes the target and pays the points.
   */
  attemptShot(): "fire" | "backfire" | "blocked" {
    const game = this.gameEntity();
    if (!game || this.phase() !== PHASE_PLAYING) {
      return "blocked";
    }
    if (this.playerFrozen()) {
      return "blocked";
    }
    if (!this.canFire()) {
      return "blocked";
    }
    const shots = game.getValue(GameState, "shotsReady") ?? MAGAZINE_SIZE;
    if (shots > 0) {
      game.setValue(GameState, "shotsReady", shots - 1);
      // First spent shot starts the recharge timer; update() keeps ticking
      // it until the magazine is full again.
      if ((game.getValue(GameState, "nextRechargeAt") ?? 0) === 0) {
        game.setValue(
          GameState,
          "nextRechargeAt",
          this.lastTime + SHOT_RECHARGE_SECONDS,
        );
      }
      this.recordShot();
      return "fire";
    }
    // Magazine empty — the red light. The shot backfires and freezes YOU.
    game.setValue(
      GameState,
      "playerFrozenUntil",
      this.lastTime + BACKFIRE_FREEZE_SECONDS,
    );
    game.setValue(
      GameState,
      "nextRechargeAt",
      this.lastTime + SHOT_RECHARGE_SECONDS,
    );
    this.recordShot();
    return "backfire";
  }

  /**
   * DAVID'S COMBO (multiplayer only): freeze your friend AND the monster,
   * and the monster thaws first and eats your friend — 5 points. There are
   * no friends in this single-player slice, so nothing calls this yet; the
   * rule lives here so the multiplayer build can award it from one place.
   */
  awardCombo() {
    const game = this.gameEntity();
    if (!game || this.phase() !== PHASE_PLAYING) {
      return;
    }
    this.addPoints(POINTS_PER_COMBO);
  }

  /**
   * Freeze the creature. Returns true if the shot counted (the creature was
   * not already frozen — only then does it pay points). Re-freezing an
   * already-frozen creature just tops up its freeze timer. The shot itself
   * (magazine, cooldown, backfire) is owned by attemptShot() — this only
   * applies a shot that already went out.
   */
  freezeCreature(creatureEntity: Entity): boolean {
    const game = this.gameEntity();
    if (!game || this.phase() !== PHASE_PLAYING) {
      return false;
    }
    const alreadyFrozen =
      (creatureEntity.getValue(Creature, "frozenUntil") ?? 0) > this.lastTime;
    const duration = game.getValue(GameState, "freezeDuration") ?? FREEZE_SECONDS_MK1;
    creatureEntity.setValue(Creature, "frozenUntil", this.lastTime + duration);
    if (!alreadyFrozen) {
      this.addPoints(POINTS_PER_FREEZE);
      return true;
    }
    return false;
  }

  /**
   * Install a carried part on the car frame: hide the part, light up its slot
   * on the frame, pay points, and check for the win.
   */
  installPart(partEntity: Entity) {
    const game = this.gameEntity();
    if (!game || this.phase() !== PHASE_PLAYING) {
      return;
    }
    if (partEntity.getValue(CarPart, "installed")) {
      return;
    }
    const partId = partEntity.getValue(CarPart, "partId") ?? 0;
    partEntity.setValue(CarPart, "installed", true);
    if (partEntity.object3D) {
      partEntity.object3D.visible = false;
    }
    for (const slot of this.queries.slots.entities) {
      if ((slot.getValue(CarSlot, "slotIndex") ?? -1) === partId) {
        if (slot.object3D) {
          slot.object3D.visible = true;
        }
      }
    }
    game.setValue(
      GameState,
      "partsCollected",
      (game.getValue(GameState, "partsCollected") ?? 0) + 1,
    );
    this.addPoints(POINTS_PER_PART);
    AudioUtils.play(partEntity);
    if ((game.getValue(GameState, "partsCollected") ?? 0) >= PARTS_TO_WIN) {
      this.win();
    }
  }

  /**
   * Buy the freeze-gun upgrade. Returns true when the purchase went through.
   */
  tryUpgrade(): boolean {
    const game = this.gameEntity();
    if (!game || this.phase() !== PHASE_PLAYING) {
      return false;
    }
    if ((game.getValue(GameState, "gunLevel") ?? 1) >= 2) {
      return false;
    }
    if (this.points() < UPGRADE_COST) {
      return false;
    }
    game.setValue(GameState, "points", this.points() - UPGRADE_COST);
    game.setValue(GameState, "gunLevel", 2);
    game.setValue(GameState, "freezeDuration", FREEZE_SECONDS_MK2);
    return true;
  }

  /** All parts installed — the car is done, you drove out. */
  win() {
    const game = this.gameEntity();
    if (!game) {
      return;
    }
    game.setValue(GameState, "phase", PHASE_WON);
  }

  /** The creature caught the player. The run goes to the lose screen
   *  ("THE CREATURE GOT YOU!") and restarts itself a couple of seconds
   *  later — see the auto-restart in update(). A catch sends the player
   *  back to the beginning, as David expected (second playtest,
   *  2026-11-11, confirmed again in VR the same day). */
  lose() {
    const game = this.gameEntity();
    if (!game || this.phase() !== PHASE_PLAYING) {
      return;
    }
    game.setValue(GameState, "phase", PHASE_LOST);
    game.setValue(GameState, "lostAt", this.lastTime);
    game.setValue(
      GameState,
      "catches",
      (game.getValue(GameState, "catches") ?? 0) + 1,
    );
    this.setLocomotionPaused(false);
  }

  /** Put everything back for a fresh run. */
  restart() {
    const game = this.gameEntity();
    if (!game) {
      return;
    }
    game.setValue(GameState, "phase", PHASE_PLAYING);
    game.setValue(GameState, "points", 0);
    game.setValue(GameState, "partsCollected", 0);
    game.setValue(GameState, "gunLevel", 1);
    game.setValue(GameState, "freezeDuration", FREEZE_SECONDS_MK1);
    game.setValue(GameState, "fireCooldownUntil", 0);
    game.setValue(GameState, "shotsReady", MAGAZINE_SIZE);
    game.setValue(GameState, "nextRechargeAt", 0);
    game.setValue(GameState, "playerFrozenUntil", 0);
    game.setValue(GameState, "lostAt", 0);
    game.setValue(GameState, "catches", 0);
    this.setLocomotionPaused(false);

    // Drop anything the player is holding, then send the parts home.
    const grab = this.world.getSystem(GrabSystem);
    for (const part of this.queries.parts.entities) {
      if (part.hasComponent(Grabbed)) {
        grab?.forceRelease(part);
      }
      part.setValue(CarPart, "installed", false);
      if (part.object3D) {
        part.object3D.visible = true;
        part.object3D.position.set(
          part.getValue(CarPart, "homeX") ?? 0,
          part.getValue(CarPart, "homeY") ?? 0.6,
          part.getValue(CarPart, "homeZ") ?? 0,
        );
      }
    }
    for (const slot of this.queries.slots.entities) {
      if (slot.object3D) {
        slot.object3D.visible = false;
      }
    }
    // Each creature back to its own spawn; the second creature hides
    // again until 3 parts are installed (round 3).
    for (const creature of this.queries.creatures.entities) {
      creature.setValue(Creature, "frozenUntil", 0);
      const spawnAt = creature.getValue(Creature, "spawnAtParts") ?? 0;
      const homeX = creature.getValue(Creature, "homeX") ?? this.creatureSpawn.x;
      const homeZ = creature.getValue(Creature, "homeZ") ?? this.creatureSpawn.z;
      creature.setValue(Creature, "spawned", spawnAt <= 0);
      creature.setValue(Creature, "steps", 0);
      creature.setValue(
        Creature,
        "activeAfter",
        this.lastTime + GRACE_SECONDS,
      );
      if (creature.object3D) {
        creature.object3D.visible = spawnAt <= 0;
        creature.object3D.position.set(homeX, 0, homeZ);
      }
    }

    // Walk the player back to the start of the junkyard.
    this.world
      .getSystem(LocomotionSystem)
      ?.setPlayerPosition(this.playerStart);
  }
}
