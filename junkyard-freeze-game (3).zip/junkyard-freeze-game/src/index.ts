/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * ============================================================================
 * JUNKYARD FREEZE — David's Meta VR Start Developer Competition 2026 entry
 * (single-player vertical slice)
 * ============================================================================
 *
 * A mix of Five Nights at Freddy's, hide and seek, and run-and-gun in an old
 * junkyard. Creatures chase you and can't die — your freeze gun freezes them
 * for a while, then they thaw. Freezing earns points; points buy a better
 * freeze gun. Collect the 6 car parts, carry them to the garage, build the
 * car, and drive out to win. A second creature — wrench arms, taller, louder
 * footsteps — drops in once 3 parts are installed.
 *
 * INTERACTION BUILDING BLOCKS — keep all four (same list as the starter):
 *
 *  1. CONTROLLER RAY / POINTER — `ControllerRaySystem` (src/ray.ts) forces
 *     both controller rays permanently visible and adds hover/press
 *     highlighting on every `RayInteractable`.
 *
 *  2. FULL CONTROLLER INPUT MAPPING — `ControllerInputSystem` (src/input.ts)
 *     handles trigger, grip, thumbstick and A/B/X/Y, and mirrors live state
 *     onto the input HUD panel. A buys the gun upgrade, B/Y restart the run.
 *
 *  3. BACKGROUND MUSIC + SPATIAL AUDIO — `BackgroundMusicSystem`
 *     (src/music.ts) loops `public/audio/ambient-loop.wav`
 *     non-positionally, while the creature and the car parts carry positional
 *     `AudioSource` chimes that fire on interaction.
 *
 *  4. GRABBABLE OBJECTS — the 6 car parts use `DistanceGrabbable` (point
 *     the ray, hold the trigger, carry them to the garage).
 *
 * GAME SYSTEMS (src/):
 *   game.ts       GameSystem — the run's state and rules (points, shop, win/lose, restart)
 *   creature.ts   CreatureSystem — the chase, the freeze look, the catch
 *   freeze-gun.ts FreezeGunSystem — trigger -> freeze + beam
 *   car-part.ts   CarPartSystem — carry parts, install them in the garage
 *   game-hud.ts   GameHUDSystem — points/parts/gun panel + shop buttons
 * ============================================================================
 */

import {
  AssetManifest,
  AssetType,
  BoxGeometry,
  CylinderGeometry,
  DistanceGrabbable,
  Group,
  Mesh,
  MeshBasicMaterial,
  MeshStandardMaterial,
  MovementMode,
  RayInteractable,
  ScreenSpace,
  SessionMode,
  SphereGeometry,
  TorusGeometry,
  World,
} from "@iwsdk/core";

import { AudioSource, PanelUI, PlaybackMode } from "@iwsdk/core";
import type { Entity } from "@iwsdk/core";

import { EnvironmentType, LocomotionEnvironment } from "@iwsdk/core";

import { PanelSystem } from "./panel.js";
import { GameSystem } from "./game.js";
import { CreatureSystem } from "./creature.js";
import { FreezeGunSystem } from "./freeze-gun.js";
import { CarPartSystem } from "./car-part.js";
import { GameHUDSystem } from "./game-hud.js";
import { ControllerInputSystem } from "./input.js";
import { ControllerRaySystem } from "./ray.js";
import { BackgroundMusic, BackgroundMusicSystem } from "./music.js";

import {
  CAR_FRAME_POS,
  CAR_SPOTS,
  CarPart,
  CarSlot,
  CREATURE_SCALE,
  CREATURE_SPAWN,
  CREATURE_SPAWN_2,
  Creature,
  GameState,
  SECOND_CREATURE_PARTS,
} from "./game-state.js";

const assets: AssetManifest = {
  chimeSound: {
    url: "./audio/chime.mp3",
    type: AssetType.Audio,
    priority: "background",
  },
  ambientMusic: {
    url: "./audio/ambient-loop.wav",
    type: AssetType.Audio,
    priority: "background",
  },
  // Round 3: one soft metallic footstep clank per stride (see
  // scripts/make-clank.py) — preloaded so the first step isn't late.
  clankSound: {
    url: "./audio/clank.wav",
    type: AssetType.Audio,
    priority: "background",
  },
};

/** Rusty junkyard car colours. */
const CAR_COLORS = [
  0x8a4b2a, 0x5a6b6b, 0x7a7a52, 0x6b4a5a, 0x4a5a6b, 0x9a7b3a, 0x715f4a,
];
const WALL_COLOR = 0x3a3230;
const GROUND_COLOR = 0x26221f;
const GARAGE_COLOR = 0x4a5560;
const FRAME_COLOR = 0x374151;

/** The 6 car parts: id, name, colour, home position. Spread across the
 * bigger yard (round 2) so there's real hunting — one in each corner and
 * one on each long side. */
const PART_DEFS = [
  { id: 0, name: "engine", color: 0xff6b35, pos: [-14, 0.6, -11] as const },
  { id: 1, name: "wheel", color: 0x3b82f6, pos: [13, 0.6, -15] as const },
  { id: 2, name: "door", color: 0x22c55e, pos: [-13, 0.6, 9] as const },
  { id: 3, name: "battery", color: 0xeab308, pos: [14, 0.6, 6] as const },
  { id: 4, name: "headlight", color: 0xfff8e0, pos: [13, 0.6, -6] as const },
  { id: 5, name: "steering wheel", color: 0xa855f7, pos: [-13, 0.6, 0] as const },
];

/** Cars parked in rows, with gaps between them as passages — see
 * CAR_SPOTS in game-state.ts (shared with the creature's obstacle map). */
function stdMaterial(color: number, emissive = 0x000000, emissiveIntensity = 0) {
  return new MeshStandardMaterial({ color, emissive, emissiveIntensity });
}

function box(
  w: number,
  h: number,
  d: number,
  material: MeshStandardMaterial,
  x: number,
  y: number,
  z: number,
) {
  const mesh = new Mesh(new BoxGeometry(w, h, d), material);
  mesh.position.set(x, y, z);
  return mesh;
}

/** One junked car: body + cabin + 4 wheels. Optionally a second car stacked on top. */
function makeCar(color: number, stacked: boolean): Group {
  const car = new Group();
  const bodyMat = stdMaterial(color);
  const darkMat = stdMaterial(0x1a1a1a);
  car.add(box(2.0, 0.55, 0.9, bodyMat, 0, 0.45, 0));
  car.add(box(1.1, 0.5, 0.8, bodyMat, -0.1, 0.95, 0));
  for (const [wx, wz] of [
    [-0.65, 0.45],
    [0.65, 0.45],
    [-0.65, -0.45],
    [0.65, -0.45],
  ] as const) {
    const wheel = new Mesh(
      new CylinderGeometry(0.28, 0.28, 0.18, 12),
      darkMat,
    );
    wheel.rotation.x = Math.PI / 2;
    wheel.position.set(wx, 0.28, wz);
    car.add(wheel);
  }
  if (stacked) {
    // A second wreck dumped on top, turned sideways — classic junkyard.
    const top = new Group();
    top.add(box(2.0, 0.55, 0.9, stdMaterial(color), 0, 0.45, 0));
    top.add(box(1.1, 0.5, 0.8, stdMaterial(color), -0.1, 0.95, 0));
    top.position.y = 1.15;
    top.rotation.y = Math.PI / 2;
    car.add(top);
  }
  return car;
}

/** The visible shape of one car part (engine, wheel, door, battery). */
function makePartMesh(id: number, color: number): Group {
  const group = new Group();
  const mat = stdMaterial(color, color, 0.35);
  if (id === 0) {
    // Engine block.
    group.add(box(0.45, 0.35, 0.45, mat, 0, 0, 0));
    group.add(box(0.3, 0.2, 0.3, mat, 0, 0.26, 0));
  } else if (id === 1) {
    // Wheel, standing up.
    const wheel = new Mesh(new CylinderGeometry(0.32, 0.32, 0.14, 20), mat);
    wheel.rotation.x = Math.PI / 2;
    group.add(wheel);
    const hub = new Mesh(new CylinderGeometry(0.12, 0.12, 0.16, 12), mat);
    hub.rotation.x = Math.PI / 2;
    group.add(hub);
  } else if (id === 2) {
    // Car door.
    group.add(box(0.85, 0.6, 0.07, mat, 0, 0, 0));
  } else if (id === 3) {
    // Battery with two terminals.
    group.add(box(0.35, 0.25, 0.25, mat, 0, 0, 0));
    const terminal = new CylinderGeometry(0.03, 0.03, 0.08, 8);
    const t1 = new Mesh(terminal, mat);
    t1.position.set(-0.08, 0.16, 0);
    group.add(t1);
    const t2 = new Mesh(terminal, mat);
    t2.position.set(0.08, 0.16, 0);
    group.add(t2);
  } else if (id === 4) {
    // Headlight: dark housing with a glowing lens.
    const housing = new Mesh(new CylinderGeometry(0.2, 0.2, 0.12, 16), mat);
    housing.rotation.x = Math.PI / 2;
    group.add(housing);
    const lens = new Mesh(new SphereGeometry(0.15, 16, 12), mat);
    lens.position.set(0, 0, 0.08);
    group.add(lens);
  } else {
    // Steering wheel: rim, spokes, hub.
    const rim = new Mesh(new TorusGeometry(0.28, 0.035, 10, 24), mat);
    group.add(rim);
    group.add(box(0.5, 0.04, 0.04, mat, 0, 0, 0));
    group.add(box(0.04, 0.5, 0.04, mat, 0, 0, 0));
    const hub = new Mesh(new CylinderGeometry(0.07, 0.07, 0.06, 12), mat);
    hub.rotation.x = Math.PI / 2;
    group.add(hub);
  }
  return group;
}

/** A full-size wrench, built from primitives: handle + open jaw head.
 *  `length` is the handle length; the jaw sits at the top end. */
function wrench(mat: MeshStandardMaterial, length: number): Group {
  const group = new Group();
  group.add(box(0.05, length, 0.035, mat, 0, 0, 0));
  const jaw = new Mesh(new TorusGeometry(0.085, 0.024, 8, 16, Math.PI * 1.5), mat);
  jaw.position.set(0, length / 2 + 0.02, 0);
  jaw.rotation.z = -0.6;
  group.add(jaw);
  return group;
}

/** A little wrench, for fingers — same shape, pocket size. */
function tinyWrench(mat: MeshStandardMaterial): Group {
  const group = new Group();
  group.add(box(0.02, 0.1, 0.015, mat, 0, 0, 0));
  const jaw = new Mesh(new TorusGeometry(0.028, 0.009, 6, 12, Math.PI * 1.5), mat);
  jaw.position.set(0, 0.065, 0);
  group.add(jaw);
  return group;
}

/** The creature, built from ratty old car parts — David's design.
 *  Faces +Z (the chase system turns it toward the player with lookAt).
 *  Built ~1.37 m tall with the drive-shaft neck (round 3), then scaled
 *  1.4x at creation, so he stands ~1.9 m tall — clearly taller than the
 *  player. Feet at y = 0. All primitives, no model file.
 *  `arms` (creature 2 only): wrench arms — right arm a wrench with a
 *  hammer on the end, left arm two wrenches, little wrenches for fingers. */
function makeCreature(options?: { arms?: boolean }): Group {
  const creature = new Group();
  const steelMat = stdMaterial(0x3f3f46); // drive shafts, dark steel
  const gearboxMat = stdMaterial(0x4a4a48); // transmissions
  const rotorMat = stdMaterial(0x8a8a8a); // brake rotors
  const shoeMat = stdMaterial(0x6b5a3a); // brake shoes
  const motorMat = stdMaterial(0x6b4a2f); // engine block, rusty brown
  const darkMat = stdMaterial(0x1a1a1a); // housings, grille, air filter
  const bumperMat = stdMaterial(0x8a7f72); // big rusty bumper
  const lensMat = stdMaterial(0xfff8e0, 0xfff2cc, 1.5); // headlight lenses

  // --- Feet: brake rotors (flat discs) with brake shoes (curved arcs) ---
  for (const side of [-1, 1] as const) {
    const x = side * 0.16;
    const rotor = new Mesh(new CylinderGeometry(0.14, 0.14, 0.05, 20), rotorMat);
    rotor.position.set(x, 0.025, 0);
    creature.add(rotor);
    // Brake shoe: a half-ring arching over the rotor.
    const shoe = new Mesh(new TorusGeometry(0.13, 0.028, 8, 16, Math.PI), shoeMat);
    shoe.position.set(x, 0.06, 0);
    shoe.rotation.y = side * 0.3;
    creature.add(shoe);
  }

  // --- Legs: drive shafts, universal-joint balls, transmissions on top ---
  for (const side of [-1, 1] as const) {
    const x = side * 0.16;
    const shaft = new Mesh(new CylinderGeometry(0.045, 0.045, 0.5, 10), steelMat);
    shaft.position.set(x, 0.3, 0);
    creature.add(shaft);
    const joint = new Mesh(new SphereGeometry(0.06, 12, 8), steelMat);
    joint.position.set(x, 0.08, 0);
    creature.add(joint);
    // Transmission: a chunky gearbox at the top of each shaft (the hips).
    creature.add(box(0.18, 0.2, 0.16, gearboxMat, x, 0.6, 0));
  }
  // Axle joining the two transmissions.
  const axle = new Mesh(new CylinderGeometry(0.05, 0.05, 0.32, 10), steelMat);
  axle.rotation.z = Math.PI / 2;
  axle.position.set(0, 0.6, 0);
  creature.add(axle);

  // --- Body: the motor (engine block), air filter on top ---
  creature.add(box(0.55, 0.42, 0.36, motorMat, 0, 0.88, 0));
  const filter = new Mesh(new CylinderGeometry(0.1, 0.1, 0.07, 14), darkMat);
  filter.position.set(0, 1.12, 0);
  creature.add(filter);

  // --- Mouth: a dark grille opening with a big rusty bumper across it ---
  creature.add(box(0.5, 0.14, 0.03, darkMat, 0, 0.72, 0.19));
  creature.add(box(0.62, 0.09, 0.07, bumperMat, 0, 0.72, 0.22));
  for (const side of [-1, 1] as const) {
    const end = box(0.12, 0.09, 0.07, bumperMat, side * 0.34, 0.72, 0.18);
    end.rotation.y = -side * 0.5;
    creature.add(end);
  }

  // --- Neck: a short drive shaft holding the head up over the body
  // (round 3, 2026-11-12: David wanted a neck so the head sits just up
  // over the body a little). A universal-joint ball at its base, then
  // the head: a gearbox housing with the two headlight eyes. ---
  const neck = new Mesh(new CylinderGeometry(0.05, 0.05, 0.18, 10), steelMat);
  neck.position.set(0, 1.16, 0);
  creature.add(neck);
  const neckJoint = new Mesh(new SphereGeometry(0.06, 12, 8), steelMat);
  neckJoint.position.set(0, 1.08, 0);
  creature.add(neckJoint);
  creature.add(box(0.4, 0.14, 0.16, gearboxMat, 0, 1.3, 0.04));

  // --- Eyes: two big headlights — dark housings, glowing lenses ---
  for (const side of [-1, 1] as const) {
    const x = side * 0.17;
    const housing = new Mesh(new CylinderGeometry(0.13, 0.13, 0.07, 16), darkMat);
    housing.rotation.x = Math.PI / 2;
    housing.position.set(x, 1.3, 0.14);
    creature.add(housing);
    const lens = new Mesh(new SphereGeometry(0.105, 16, 12), lensMat);
    lens.position.set(x, 1.3, 0.19);
    creature.add(lens);
  }

  if (options?.arms) {
    // --- Arms (creature 2 only, round 3): built from tools, hanging at
    // the body's sides. Right arm (creature's right, -x): a wrench with
    // a hammer on the end. Left arm (+x): two wrenches, side by side.
    // Fingers on both hands are little wrenches. ---
    const rightArm = new Group();
    rightArm.position.set(-0.32, 1.0, 0);
    rightArm.rotation.z = -0.08;
    const rightWrench = wrench(steelMat, 0.5);
    rightWrench.position.y = -0.25;
    rightArm.add(rightWrench);
    // Hammer head on the far (bottom) end of the wrench.
    rightArm.add(box(0.17, 0.09, 0.09, darkMat, 0, -0.52, 0));
    for (let i = -1; i <= 1; i++) {
      const finger = tinyWrench(steelMat);
      finger.position.set(i * 0.045, -0.62, 0);
      rightArm.add(finger);
    }
    creature.add(rightArm);

    const leftArm = new Group();
    leftArm.position.set(0.32, 1.0, 0);
    leftArm.rotation.z = 0.08;
    for (const dx of [-0.035, 0.035]) {
      const leftWrench = wrench(steelMat, 0.5);
      leftWrench.position.set(dx, -0.25, 0);
      leftArm.add(leftWrench);
    }
    for (let i = -1; i <= 1; i++) {
      const finger = tinyWrench(steelMat);
      finger.position.set(i * 0.05, -0.6, 0);
      leftArm.add(finger);
    }
    creature.add(leftArm);
  }

  return creature;
}

/** Translucent ice block, hidden until the creature is frozen. Sized to
 * cover the whole creature (~1.9 m tall after the 1.4x scale, arms
 * included — the box is a child of the creature group, so it scales too). */
function addIceBox(creatureMesh: Group) {
  const iceBox = new Mesh(
    new BoxGeometry(1.0, 1.45, 0.8),
    new MeshBasicMaterial({
      color: 0x9fd8ff,
      transparent: true,
      opacity: 0.3,
    }),
  );
  iceBox.name = "ice-box";
  iceBox.position.set(0, 0.68, 0);
  iceBox.visible = false;
  creatureMesh.add(iceBox);
}

World.create(document.getElementById("scene-container") as HTMLDivElement, {
  assets,
  // IWSDK 0.5 dropped the implicit default environment: EnvironmentSystem only
  // applies DomeGradient/IBLGradient on the level-root entity, so the sky and
  // image-based lighting now come from this (otherwise empty) scene document.
  // Everything else in the scene is still built procedurally below.
  level: "./scenes/main.iwsdk.scene.json",
  xr: {
    sessionMode: SessionMode.ImmersiveVR,
    offer: "always",
    features: { handTracking: true, layers: true },
  },
  features: {
    locomotion: {
      useWorker: true,
      // The player starts at the south end of the yard, facing the junkyard.
      initialPlayerPosition: [0, 0, 6],
      // WASD in the browser preview, so the game can be walked around
      // without a headset too.
      browserControls: true,
    },
    grabbing: true,
    physics: false,
    sceneUnderstanding: false,
    environmentRaycast: false,
  },
}).then((world) => {
  const { camera } = world;

  // Browser view: stand at the south end, look north into the yard. (In XR
  // the headset drives the camera; this only sets the 2D preview.)
  camera.position.set(0, 1.6, 0);

  // --- The run's state ----------------------------------------------------
  world.createTransformEntity().addComponent(GameState);

  // --- Ground + yard walls (walkable / solid for locomotion) --------------
  // Round 2: the yard grew ~1.5x to 31 x 31 m (ground 34 x 34, centred
  // on z=-3 so it covers the new bounds with margin). Walls sit just
  // outside YARD_BOUNDS in game-state.ts.
  const ground = box(34, 0.1, 34, stdMaterial(GROUND_COLOR), 0, -0.05, -3);
  ground.name = "junkyard-ground";
  world
    .createTransformEntity(ground)
    .addComponent(LocomotionEnvironment, { type: EnvironmentType.STATIC });

  const wallMat = stdMaterial(WALL_COLOR);
  const walls: Array<[number, number, number, number, number, number]> = [
    // w, h, d, x, y, z — north, south, west, east
    [34, 2.5, 0.3, 0, 1.25, -19],
    [34, 2.5, 0.3, 0, 1.25, 13],
    [0.3, 2.5, 32, -16, 1.25, -3],
    [0.3, 2.5, 32, 16, 1.25, -3],
  ];
  for (const [w, h, d, x, y, z] of walls) {
    const wall = box(w, h, d, wallMat, x, y, z);
    world
      .createTransformEntity(wall)
      .addComponent(LocomotionEnvironment, { type: EnvironmentType.STATIC });
  }

  // --- Stacked-car passages ----------------------------------------------
  CAR_SPOTS.forEach((spot, i) => {
    const car = makeCar(CAR_COLORS[i % CAR_COLORS.length], spot.stacked);
    car.position.set(spot.x, 0, spot.z);
    car.rotation.y = spot.rot;
    car.name = `junk-car-${i}`;
    world
      .createTransformEntity(car)
      .addComponent(LocomotionEnvironment, { type: EnvironmentType.STATIC });
  });

  // --- The garage (your little room, north end) ---------------------------
  // Round 2: the garage moved to the new north edge with the bigger yard
  // (back wall z=-18.6, car frame at z=-16.3 — see CAR_FRAME_POS).
  const garageMat = stdMaterial(GARAGE_COLOR);
  // Thin floor marking for the garage — flush with the ground so the player
  // can walk straight in (visual only, no collision of its own).
  const pad = box(4.4, 0.02, 4.0, garageMat, 0, 0.0, -16.6);
  world.createTransformEntity(pad);
  const garageWalls: Array<[number, number, number, number, number, number]> = [
    [4.4, 2.6, 0.15, 0, 1.3, -18.6], // back
    [0.15, 2.6, 4.0, -2.2, 1.3, -16.7], // west
    [0.15, 2.6, 4.0, 2.2, 1.3, -16.7], // east (front stays open)
  ];
  for (const [w, h, d, x, y, z] of garageWalls) {
    const wall = box(w, h, d, garageMat, x, y, z);
    world
      .createTransformEntity(wall)
      .addComponent(LocomotionEnvironment, { type: EnvironmentType.STATIC });
  }

  // The car frame you are building, inside the garage.
  const frame = new Group();
  frame.add(box(1.9, 0.35, 0.95, stdMaterial(FRAME_COLOR), 0, 0.45, 0));
  const stubMat = stdMaterial(0x111111);
  for (const [wx, wz] of [
    [-0.65, 0.42],
    [0.65, 0.42],
    [-0.65, -0.42],
    [0.65, -0.42],
  ] as const) {
    const stub = new Mesh(new CylinderGeometry(0.25, 0.25, 0.15, 12), stubMat);
    stub.rotation.x = Math.PI / 2;
    stub.position.set(wx, 0.25, wz);
    frame.add(stub);
  }
  frame.position.set(CAR_FRAME_POS[0], 0, CAR_FRAME_POS[2]);
  frame.name = "car-frame";
  world
    .createTransformEntity(frame)
    .addComponent(LocomotionEnvironment, { type: EnvironmentType.STATIC });

  // Glowing shapes that appear on the frame as each part is installed.
  const slotDefs = [
    { id: 0, mesh: box(0.6, 0.4, 0.6, stdMaterial(0xff6b35, 0xff6b35, 0.5), 0.45, 0.85, 0) },
    {
      id: 1,
      mesh: (() => {
        const m = new Mesh(
          new CylinderGeometry(0.32, 0.32, 0.14, 20),
          stdMaterial(0x3b82f6, 0x3b82f6, 0.5),
        );
        m.rotation.x = Math.PI / 2;
        m.position.set(-0.7, 0.35, 0.55);
        return m;
      })(),
    },
    { id: 2, mesh: box(0.08, 0.6, 0.85, stdMaterial(0x22c55e, 0x22c55e, 0.5), 0.1, 0.75, 0.5) },
    { id: 3, mesh: box(0.35, 0.25, 0.25, stdMaterial(0xeab308, 0xeab308, 0.5), -0.5, 0.8, 0) },
    {
      id: 4,
      mesh: (() => {
        const m = new Mesh(
          new CylinderGeometry(0.16, 0.16, 0.1, 16),
          stdMaterial(0xfff8e0, 0xfff8e0, 0.6),
        );
        m.rotation.x = Math.PI / 2;
        m.position.set(0.7, 0.7, -0.35);
        return m;
      })(),
    },
    {
      id: 5,
      mesh: (() => {
        const m = new Mesh(
          new TorusGeometry(0.22, 0.03, 10, 24),
          stdMaterial(0xa855f7, 0xa855f7, 0.5),
        );
        m.position.set(-0.15, 0.85, -0.4);
        return m;
      })(),
    },
  ];
  for (const slot of slotDefs) {
    slot.mesh.position.x += CAR_FRAME_POS[0];
    slot.mesh.position.z += CAR_FRAME_POS[2];
    slot.mesh.visible = false;
    world
      .createTransformEntity(slot.mesh)
      .addComponent(CarSlot, { slotIndex: slot.id });
  }

  /** A positional footstep AudioSource riding on a creature (round 3):
   * a child entity parented to the creature, so each clank comes from
   * where the creature is standing and fades with distance. Returns the
   * entity for the Creature.stepAudio field. */
  function makeStepAudio(parent: Entity): Entity {
    const audio = world.createTransformEntity(undefined, { parent });
    audio.object3D!.position.set(0, 0.5, 0);
    audio.object3D!.name = "step-audio";
    audio.addComponent(AudioSource, {
      src: "./audio/clank.wav",
      volume: 0.5,
      positional: true,
      playbackMode: PlaybackMode.Overlap,
      maxInstances: 2,
    });
    return audio;
  }

  // --- The creature (built from old car parts — see makeCreature) --------
  const creatureMesh = makeCreature();
  creatureMesh.position.set(CREATURE_SPAWN[0], 0, CREATURE_SPAWN[2]);
  // Round 3: David said he is still smaller than the player — scale him
  // up 1.4x on the new neck build, so he stands ~1.9 m tall. The ice
  // block is a child, so it scales too.
  creatureMesh.scale.setScalar(CREATURE_SCALE);
  creatureMesh.name = "creature";
  addIceBox(creatureMesh);
  const creatureEntity = world
    .createTransformEntity(creatureMesh)
    .addComponent(RayInteractable)
    .addComponent(Creature, {
      homeX: CREATURE_SPAWN[0],
      homeZ: CREATURE_SPAWN[2],
    })
    .addComponent(AudioSource, {
      src: "./audio/chime.mp3",
      maxInstances: 3,
      playbackMode: PlaybackMode.FadeRestart,
    });
  creatureEntity.setValue(Creature, "stepAudio", makeStepAudio(creatureEntity));

  // --- The second creature (round 3): same build, wrench arms, drops in
  // once 3 parts are installed — hidden until then, so the yard starts
  // with one hunter and gets harder halfway through. ---
  const creature2Mesh = makeCreature({ arms: true });
  creature2Mesh.position.set(CREATURE_SPAWN_2[0], 0, CREATURE_SPAWN_2[2]);
  creature2Mesh.scale.setScalar(CREATURE_SCALE);
  creature2Mesh.name = "creature-2";
  addIceBox(creature2Mesh);
  creature2Mesh.visible = false;
  const creature2Entity = world
    .createTransformEntity(creature2Mesh)
    .addComponent(RayInteractable)
    .addComponent(Creature, {
      spawnAtParts: SECOND_CREATURE_PARTS,
      spawned: false,
      homeX: CREATURE_SPAWN_2[0],
      homeZ: CREATURE_SPAWN_2[2],
      activeAfter: 1e9, // not hunting until it spawns (set on spawn)
    })
    .addComponent(AudioSource, {
      src: "./audio/chime.mp3",
      maxInstances: 3,
      playbackMode: PlaybackMode.FadeRestart,
    });
  creature2Entity.setValue(Creature, "stepAudio", makeStepAudio(creature2Entity));

  // --- The 6 car parts, scattered around the yard -------------------------
  for (const def of PART_DEFS) {
    const partMesh = makePartMesh(def.id, def.color);
    partMesh.position.set(def.pos[0], def.pos[1], def.pos[2]);
    partMesh.name = `part-${def.name}`;
    world
      .createTransformEntity(partMesh)
      .addComponent(RayInteractable)
      // BUILDING BLOCK 4 — grab at a distance: point the ray, hold trigger.
      .addComponent(DistanceGrabbable, {
        movementMode: MovementMode.MoveTowardsTarget,
      })
      .addComponent(CarPart, {
        partId: def.id,
        homeX: def.pos[0],
        homeY: def.pos[1],
        homeZ: def.pos[2],
      })
      .addComponent(AudioSource, {
        src: "./audio/chime.mp3",
        maxInstances: 2,
        playbackMode: PlaybackMode.FadeRestart,
      });
  }

  // BUILDING BLOCK 3 — background music: non-positional, looping, plays from
  // the listener so it stays at a constant level wherever the player walks.
  world
    .createTransformEntity()
    .addComponent(BackgroundMusic)
    .addComponent(AudioSource, {
      src: "./audio/ambient-loop.wav",
      positional: false,
      loop: true,
      autoplay: true,
      volume: 0.35,
    });

  // Welcome panel — the game's title card + Enter XR button. It stands just
  // in front of where the player starts, so it is readable on arrival.
  const panelEntity = world
    .createTransformEntity()
    .addComponent(PanelUI, { config: "./ui/welcome.uikitml" })
    .addComponent(RayInteractable)
    .addComponent(ScreenSpace, {
      top: "20px",
      left: "20px",
      height: "40%",
    });
  panelEntity.object3D!.position.set(0, 1.29, 4.5);
  panelEntity.object3D!.scale.setScalar(2.9);

  // Game HUD — points, parts, gun, status, shop buttons. It stands at the
  // garage entrance, where parts get delivered and runs are won, so the
  // score and the win message are right where the action ends. (Round 2:
  // moved to the new garage mouth at z=-13.5, clear of the car rows.)
  const gameHudEntity = world
    .createTransformEntity()
    .addComponent(PanelUI, { config: "./ui/game-hud.uikitml" })
    .addComponent(RayInteractable)
    .addComponent(ScreenSpace, {
      bottom: "20px",
      left: "20px",
      height: "40%",
    });
  gameHudEntity.object3D!.position.set(0, 1.5, -13.5);
  gameHudEntity.object3D!.scale.setScalar(1.9);

  // Controller input HUD — live button/trigger/stick mirror (starter block).
  const hudPanelEntity = world
    .createTransformEntity()
    .addComponent(PanelUI, { config: "./ui/input-hud.uikitml" })
    .addComponent(RayInteractable)
    .addComponent(ScreenSpace, {
      top: "20px",
      right: "20px",
      height: "30%",
    });
  hudPanelEntity.object3D!.position.set(1.7, 1.1, 3.5);
  hudPanelEntity.object3D!.scale.setScalar(1.9);

  world
    .registerSystem(GameSystem)
    .registerSystem(PanelSystem)
    .registerSystem(CreatureSystem)
    .registerSystem(FreezeGunSystem)
    .registerSystem(CarPartSystem)
    .registerSystem(GameHUDSystem)
    .registerSystem(ControllerRaySystem)
    .registerSystem(BackgroundMusicSystem)
    .registerSystem(ControllerInputSystem);
});
