/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  AudioUtils,
  Color,
  createSystem,
  Mesh,
  Vector3,
} from "@iwsdk/core";
import type { Entity, Material, Object3D } from "@iwsdk/core";

import { GameSystem } from "./game.js";
import {
  CAR_BLOCK_RADIUS,
  CAR_FRAME_BLOCK_RADIUS,
  CAR_FRAME_POS,
  CAR_SPOTS,
  CATCH_DISTANCE,
  CREATURE_BASE_SPEED,
  CREATURE_BODY_RADIUS,
  CREATURE_SPEED_PER_PART,
  CREATURE_STEP_LENGTH,
  CREATURE_STUCK_SECONDS,
  CREATURE_UNSTICK_SECONDS,
  Creature,
  GARAGE_WALL_SEGMENTS,
  GameState,
  PHASE_PLAYING,
  YARD_BOUNDS,
} from "./game-state.js";

/** Materials that can carry a colour + emissive tint. */
type EmissiveMaterial = Material & {
  color: Color;
  emissive: Color;
  emissiveIntensity: number;
};

function isEmissive(material: Material): material is EmissiveMaterial {
  const m = material as EmissiveMaterial;
  return m.emissive instanceof Color && m.color instanceof Color;
}

/** Icy look while frozen: pale blue body, cold blue glow. */
const FROZEN_COLOR = 0x9fd8ff;
const FROZEN_EMISSIVE = 0x3a7bd5;
const FROZEN_EMISSIVE_INTENSITY = 0.55;

/**
 * The creature — built from old car parts (drive-shaft legs, rotor feet, a
 * motor body, a bumper mouth, headlight eyes). It walks toward the
 * player, it can't be killed, it can only be frozen. If it touches the
 * player, the run is over.
 *
 * Frozen behaviour: it stops dead, turns icy blue, and a translucent ice
 * block (a child Object3D named "ice-box", built in index.ts) appears around
 * it until the freeze timer runs out.
 *
 * Obstacles (added 2026-11-10, after David's first playtest: the creature
 * chased in a straight line, ran into a car, and parked there): the creature
 * has no physics body, so it walks around the cars, garage walls, and car
 * frame on a ground-plane obstacle map (game-state.ts) — it slides along
 * them instead of dead-stopping, and if it gets wedged anyway (barely
 * moving for ~2s while chasing) it sidesteps sideways for a short burst.
 * Its look, speed (1.25 m/s + 0.12/part), freeze/thaw, and catch distance
 * (0.8 m) are unchanged. Round 2 (2026-11-11): the yard grew to 31 x 31 m
 * with 28 cars, and the creature grew 1.3x taller — the obstacle map in
 * game-state.ts grew with it, so the slide/sidestep behaviour is the same.
 * The bigger yard also put a car dead centre on the spawn-to-player line,
 * and a headless probe caught the creature shuffling along that car's edge
 * for 100+ seconds: the old stuck check measured raw movement, and sliding
 * counts as movement. It now measures progress toward the player — if it
 * hasn't closed in for ~2s it sidesteps in one persistent direction
 * (flipping only when that side is a dead end) for the full burst.
 *
 * Round 3 (2026-11-12): a second creature drops in once 3 parts are
 * installed (Creature.spawnAtParts) — same chase, same rules, wrench arms.
 * Both creatures grew to ~1.9 m tall with a drive-shaft neck, and both
 * make footstep sounds: one soft metallic clank per stride, played
 * through a positional AudioSource riding on the creature, so it is
 * louder up close and fades with distance — you can hear them coming.
 */
export class CreatureSystem extends createSystem({
  creatures: { required: [Creature] },
  game: { required: [GameState] },
}) {
  private headPos!: Vector3;
  private creaturePos!: Vector3;
  private moveDir!: Vector3;
  /** Original material colours, so the frozen tint can be undone exactly. */
  private originals = new Map<
    EmissiveMaterial,
    { hex: number; emissiveHex: number; intensity: number }
  >();
  /** Cached ice-box child per creature entity index. */
  private iceBoxes = new Map<number, Object3D | null>();
  /** Stuck + footstep tracking per creature entity index. */
  private stuck = new Map<
    number,
    {
      lastDist: number;
      lastProgressTime: number;
      unstickUntil: number;
      unstickDir: number;
      /** Last chase position (for stride measurement). */
      prevX: number;
      prevZ: number;
      hasPrev: boolean;
      /** Metres walked since the last footstep clank. */
      stepAcc: number;
    }
  >();

  init() {
    this.headPos = new Vector3();
    this.creaturePos = new Vector3();
    this.moveDir = new Vector3();
  }

  update(delta: number, time: number) {
    const gameSystem = this.world.getSystem(GameSystem);
    const playing = gameSystem?.phase() === PHASE_PLAYING;
    let parts = 0;
    for (const gameEntity of this.queries.game.entities) {
      parts = gameEntity.getValue(GameState, "partsCollected") ?? 0;
      break;
    }
    const speed =
      CREATURE_BASE_SPEED + parts * CREATURE_SPEED_PER_PART;

    // Second creature drops in halfway through the run (round 3): once
    // the parts count reaches its spawnAtParts, reveal it and let it hunt
    // right away — it spawns far from the player, so no grace is needed.
    for (const creature of this.queries.creatures.entities) {
      const spawned = creature.getValue(Creature, "spawned") ?? true;
      if (spawned) {
        continue;
      }
      const spawnAt = creature.getValue(Creature, "spawnAtParts") ?? 0;
      if (playing && parts >= spawnAt) {
        creature.setValue(Creature, "spawned", true);
        creature.setValue(Creature, "activeAfter", time);
        if (creature.object3D) {
          creature.object3D.visible = true;
        }
        this.resetStuck(creature, time);
      }
    }

    for (const creature of this.queries.creatures.entities) {
      // Not spawned yet — hidden, still, silent.
      if (!(creature.getValue(Creature, "spawned") ?? true)) {
        continue;
      }
      const frozenUntil = creature.getValue(Creature, "frozenUntil") ?? 0;
      const frozen = playing && time < frozenUntil;
      this.setFrozenLook(creature, frozen);

      if (!playing || frozen) {
        this.resetStuck(creature, time);
        continue;
      }

      // Grace period at the start of a run: the creature waits at its spawn
      // so the player can read the panels and get moving first.
      const activeAfter = creature.getValue(Creature, "activeAfter") ?? 0;
      if (time < activeAfter) {
        this.resetStuck(creature, time);
        continue;
      }

      // Chase the player across the ground (flat, no flying).
      this.player.head.getWorldPosition(this.headPos);
      creature.object3D?.getWorldPosition(this.creaturePos);
      this.moveDir.set(
        this.headPos.x - this.creaturePos.x,
        0,
        this.headPos.z - this.creaturePos.z,
      );
      const distance = this.moveDir.length();
      if (distance < CATCH_DISTANCE) {
        // Caught: the run shows "THE CREATURE GOT YOU!" briefly, then
        // restarts itself (GameSystem.update() auto-restarts after the
        // lose pause — David's expectation from the 2026-11-11 playtests:
        // a catch sends you back to the beginning, it never just sits
        // on the end screen waiting for a manual restart).
        gameSystem?.lose();
        continue;
      }
      if (distance > 0.001) {
        this.moveDir.divideScalar(distance);
        const obj = creature.object3D!;
        const step = speed * delta;
        const st = this.stuckState(creature.index, time);
        const px = -this.moveDir.z * st.unstickDir;
        const pz = this.moveDir.x * st.unstickDir;
        if (time < st.unstickUntil) {
          // Unstick burst: sidestep sideways for the full burst. The
          // direction persists across bursts — flipping it every time
          // just shuttles the creature back and forth in front of the
          // same car. Only flip when this side is a dead end (the
          // sidestep itself is blocked by a wall or another car).
          if (!this.tryStep(obj, px * step, pz * step)) {
            st.unstickDir = -st.unstickDir;
            this.tryStep(obj, -px * step, -pz * step);
          }
        } else if (
          this.isFree(
            obj.position.x + this.moveDir.x * step,
            obj.position.z + this.moveDir.z * step,
          )
        ) {
          // Clear run at the player — moving freely, so not stuck.
          this.tryStep(obj, this.moveDir.x * step, this.moveDir.z * step);
          st.lastProgressTime = time;
        } else if (
          !this.tryStep(obj, this.moveDir.x * step, this.moveDir.z * step)
        ) {
          // Dead-stopped against something: sidestep right away instead
          // of parking on the obstacle.
          this.tryStep(obj, px * step, pz * step);
        }
        // Progress tracking (round 2, 2026-11-11: the bigger yard put a
        // car dead centre on the spawn-to-player line, and the creature
        // sat there for 100+ seconds in a headless probe). Sliding along
        // a car's edge counts as movement, but it never gets the
        // creature any closer to the player — so the stuck check
        // measures progress toward the player, not raw movement. If it
        // hasn't closed in for ~2s while chasing, force a sidestep
        // burst in the persistent direction.
        if (distance < st.lastDist - 0.15) {
          st.lastDist = distance;
          st.lastProgressTime = time;
        } else if (
          time - st.lastProgressTime > CREATURE_STUCK_SECONDS &&
          time >= st.unstickUntil
        ) {
          st.unstickUntil = time + CREATURE_UNSTICK_SECONDS;
          st.lastProgressTime = time;
        }
        // Face the player (keep the creature upright — look at head height
        // would tilt it, so aim at its own height).
        obj.lookAt(this.headPos.x, obj.position.y, this.headPos.z);

        // Footsteps (round 3): one soft metallic clank per stride, so the
        // clanking tracks how fast the creature is moving. Strides are
        // measured from real ground covered, not from time — a creature
        // wedged against a car doesn't clank in place, and a faster one
        // clanks more often. The clank itself is positional (a child
        // AudioSource riding on the creature), so it fades with distance.
        if (st.hasPrev) {
          const moved = Math.hypot(
            obj.position.x - st.prevX,
            obj.position.z - st.prevZ,
          );
          // The cap only guards against teleports (restart puts the
          // creature back at spawn — but that path clears hasPrev first,
          // so this is a backstop). It must stay well above one frame of
          // walking even at very low frame rates: under SwiftShader the
          // probe runs at ~1 fps, so a single frame can cover ~2 m.
          if (moved > 0.0005 && moved < 5.0) {
            st.stepAcc += moved;
          }
        }
        st.prevX = obj.position.x;
        st.prevZ = obj.position.z;
        st.hasPrev = true;
        while (st.stepAcc >= CREATURE_STEP_LENGTH) {
          st.stepAcc -= CREATURE_STEP_LENGTH;
          this.playStep(creature, distance);
        }
      }
    }
  }

  /** One footstep clank from this creature's positional step audio.
   * Volume is scaled by distance to the player on top of the positional
   * falloff — loud up close (the warning that one is coming), a soft
   * tick from across the yard. Kept subtle: the file itself peaks low,
   * and this caps at 0.6 even point-blank. */
  private playStep(creature: Entity, distance: number) {
    const audio = creature.getValue(Creature, "stepAudio");
    if (!audio) {
      return;
    }
    const volume = Math.max(0.12, Math.min(0.6, 0.6 * (1 - distance / 30)));
    AudioUtils.setVolume(audio, volume);
    AudioUtils.play(audio);
    creature.setValue(
      Creature,
      "steps",
      (creature.getValue(Creature, "steps") ?? 0) + 1,
    );
  }

  /** Stuck + footstep state for one creature, created on first chase.
   * Progress is measured toward the player (lastDist), not raw movement
   * — sliding along a car's edge is movement without progress. */
  private stuckState(
    index: number,
    time: number,
  ): {
    lastDist: number;
    lastProgressTime: number;
    unstickUntil: number;
    unstickDir: number;
    prevX: number;
    prevZ: number;
    hasPrev: boolean;
    stepAcc: number;
  } {
    let st = this.stuck.get(index);
    if (!st) {
      st = {
        lastDist: Infinity,
        lastProgressTime: time,
        unstickUntil: 0,
        unstickDir: 1,
        prevX: 0,
        prevZ: 0,
        hasPrev: false,
        stepAcc: 0,
      };
      this.stuck.set(index, st);
    }
    return st;
  }

  /** Forget any stuck/footstep state while the creature isn't chasing
   * (frozen, grace, run over, or not spawned yet) so it doesn't sidestep
   * the moment it resumes, or clank for a teleport on restart. */
  private resetStuck(creature: Entity, time: number) {
    const st = this.stuckState(creature.index, time);
    st.lastDist = Infinity;
    st.lastProgressTime = time;
    st.unstickUntil = 0;
    st.hasPrev = false;
    st.stepAcc = 0;
  }

  /** True when the creature may stand at (x, z): inside the yard, clear of
   * every car, the garage walls, and the car frame. */
  private isFree(x: number, z: number): boolean {
    if (
      x < YARD_BOUNDS.minX ||
      x > YARD_BOUNDS.maxX ||
      z < YARD_BOUNDS.minZ ||
      z > YARD_BOUNDS.maxZ
    ) {
      return false;
    }
    for (const spot of CAR_SPOTS) {
      const dx = x - spot.x;
      const dz = z - spot.z;
      if (dx * dx + dz * dz < CAR_BLOCK_RADIUS * CAR_BLOCK_RADIUS) {
        return false;
      }
    }
    const fx = x - CAR_FRAME_POS[0];
    const fz = z - CAR_FRAME_POS[2];
    if (
      fx * fx + fz * fz <
      CAR_FRAME_BLOCK_RADIUS * CAR_FRAME_BLOCK_RADIUS
    ) {
      return false;
    }
    for (const wall of GARAGE_WALL_SEGMENTS) {
      if (this.distToSegment(x, z, wall) < CREATURE_BODY_RADIUS) {
        return false;
      }
    }
    return true;
  }

  /** Shortest distance from a ground point to a wall segment. */
  private distToSegment(
    px: number,
    pz: number,
    seg: { x1: number; z1: number; x2: number; z2: number },
  ): number {
    const dx = seg.x2 - seg.x1;
    const dz = seg.z2 - seg.z1;
    const lenSq = dx * dx + dz * dz;
    let t = lenSq > 0 ? ((px - seg.x1) * dx + (pz - seg.z1) * dz) / lenSq : 0;
    t = Math.max(0, Math.min(1, t));
    const cx = seg.x1 + t * dx;
    const cz = seg.z1 + t * dz;
    return Math.hypot(px - cx, pz - cz);
  }

  /** Move the creature's Object3D by (dx, dz), sliding along obstacles:
   * try the full step, then the X-only and Z-only parts of it. Returns true
   * when it moved at all. */
  private tryStep(obj: Object3D, dx: number, dz: number): boolean {
    const x = obj.position.x;
    const z = obj.position.z;
    if (this.isFree(x + dx, z + dz)) {
      obj.position.x = x + dx;
      obj.position.z = z + dz;
      return true;
    }
    if (dx !== 0 && this.isFree(x + dx, z)) {
      obj.position.x = x + dx;
      return true;
    }
    if (dz !== 0 && this.isFree(x, z + dz)) {
      obj.position.z = z + dz;
      return true;
    }
    return false;
  }

  /** Icy tint + ice block while frozen; plain junkyard self otherwise. */
  private setFrozenLook(creature: Entity, frozen: boolean) {
    const root = creature.object3D;
    if (!root) {
      return;
    }
    let ice = this.iceBoxes.get(creature.index);
    if (ice === undefined) {
      ice = root.getObjectByName("ice-box") ?? null;
      this.iceBoxes.set(creature.index, ice);
    }
    if (ice) {
      ice.visible = frozen;
    }
    root.traverse((child) => {
      const mesh = child as Mesh;
      if (!mesh.isMesh) {
        return;
      }
      const materials = Array.isArray(mesh.material)
        ? mesh.material
        : [mesh.material];
      for (const material of materials) {
        if (!isEmissive(material)) {
          continue;
        }
        let original = this.originals.get(material);
        if (!original) {
          original = {
            hex: material.color.getHex(),
            emissiveHex: material.emissive.getHex(),
            intensity: material.emissiveIntensity,
          };
          this.originals.set(material, original);
        }
        if (frozen) {
          material.color.setHex(FROZEN_COLOR);
          material.emissive.setHex(FROZEN_EMISSIVE);
          material.emissiveIntensity = FROZEN_EMISSIVE_INTENSITY;
        } else {
          material.color.setHex(original.hex);
          material.emissive.setHex(original.emissiveHex);
          material.emissiveIntensity = original.intensity;
        }
      }
    });
  }
}
