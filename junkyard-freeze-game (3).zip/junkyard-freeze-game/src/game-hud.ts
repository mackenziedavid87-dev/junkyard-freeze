/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  createSystem,
  eq,
  PanelDocument,
  PanelUI,
  UIKit,
  UIKitDocument,
} from "@iwsdk/core";

import { GameSystem } from "./game.js";
import {
  FREEZE_SECONDS_MK1,
  FREEZE_SECONDS_MK2,
  GameState,
  MAGAZINE_SIZE,
  PARTS_TO_WIN,
  PHASE_LOST,
  PHASE_PLAYING,
  PHASE_WON,
  UPGRADE_COST,
} from "./game-state.js";

const HUD_INTERVAL = 0.1; // seconds between HUD refreshes

/**
 * The game HUD panel (public/ui/game-hud.uikitml): points, parts, one
 * combined gun row (gun level, safe shots left, freeze time, upgrade cost),
 * a status line, and two buttons — upgrade the freeze gun, and restart the
 * run. Same shape as the starter's input HUD: read live values on a timer,
 * write only what changed, wire buttons through PanelDocument.
 */
export class GameHUDSystem extends createSystem({
  game: { required: [GameState] },
  hud: {
    required: [PanelUI, PanelDocument],
    where: [eq(PanelUI, "config", "./ui/game-hud.uikitml")],
  },
}) {
  private hudEls: Record<string, UIKit.Text> = {};
  private hudCache: Record<string, string> = {};
  private lastHud = 0;

  init() {
    this.queries.hud.subscribe("qualify", (entity) => {
      const doc = PanelDocument.data.document[entity.index] as UIKitDocument;
      if (!doc) {
        return;
      }
      for (const id of [
        "hud-points",
        "hud-parts",
        "hud-gun",
        "hud-status",
      ]) {
        const el = doc.getElementById(id) as UIKit.Text | null;
        if (el) {
          this.hudEls[id] = el;
        }
      }
      // NOTE: the upgrade button keeps its static "UPGRADE GUN" label. The
      // cost / ready state lives in the gun row above it, because
      // setProperties({ text }) does not update a <button> label at runtime
      // (verified in the emulator: the label stayed on its static text).
      const upgradeButton = doc.getElementById(
        "upgrade-button",
      ) as UIKit.Text | null;
      if (upgradeButton) {
        upgradeButton.addEventListener("click", () => {
          this.world.getSystem(GameSystem)?.tryUpgrade();
        });
      }
      const restartButton = doc.getElementById(
        "restart-button",
      ) as UIKit.Text | null;
      if (restartButton) {
        this.hudEls["restart-button"] = restartButton;
        restartButton.addEventListener("click", () => {
          this.world.getSystem(GameSystem)?.restart();
        });
      }
    });
  }

  update(_delta: number, time: number) {
    if (time - this.lastHud < HUD_INTERVAL) {
      return;
    }
    this.lastHud = time;
    const game = this.world.getSystem(GameSystem);
    if (!game) {
      return;
    }
    const gameEntity = game.gameEntity();
    if (!gameEntity) {
      return;
    }
    const phase = gameEntity.getValue(GameState, "phase") ?? PHASE_PLAYING;
    const points = gameEntity.getValue(GameState, "points") ?? 0;
    const parts = gameEntity.getValue(GameState, "partsCollected") ?? 0;
    const gunLevel = gameEntity.getValue(GameState, "gunLevel") ?? 1;
    const freezeSeconds =
      gameEntity.getValue(GameState, "freezeDuration") ?? FREEZE_SECONDS_MK1;
    const shots = game.shotsReady();
    const frozen = game.playerFrozen();

    this.setHud("hud-points", `POINTS  ${points}`);
    this.setHud("hud-parts", `PARTS  ${parts} / ${PARTS_TO_WIN}`);
    // Gun, shots and upgrade state share one row: the HUD's 4th row
    // overlapped the 3rd in the emulator, so the panel is back to the
    // original 3-row shape. "UPG" is the upgrade cost / ready state.
    const upgradeState =
      gunLevel >= 2
        ? "MAXED"
        : points >= UPGRADE_COST
          ? "UPG READY!"
          : `UPG ${UPGRADE_COST} PTS`;
    this.setHud(
      "hud-gun",
      gunLevel >= 2
        ? `GUN Mk II | SHOTS ${shots}/${MAGAZINE_SIZE} | ${Math.round(FREEZE_SECONDS_MK2)}s freeze | ${upgradeState}`
        : `GUN Mk I | SHOTS ${shots}/${MAGAZINE_SIZE} | ${Math.round(freezeSeconds)}s freeze | ${upgradeState}`,
    );

    if (phase === PHASE_WON) {
      this.setHud("hud-status", "YOU DROVE OUT! YOU WIN!");
    } else if (phase === PHASE_LOST) {
      // The run restarts itself a couple of seconds after a catch — the
      // status just names the moment, it doesn't ask for a manual restart.
      this.setHud("hud-status", "THE CREATURE GOT YOU!");
    } else if (frozen) {
      this.setHud("hud-status", "BACKFIRE! YOU'RE FROZEN!");
    } else if (shots === 0) {
      // No safe shot left — the red light is lit. Firing now backfires.
      this.setHud("hud-status", "RED LIGHT! Wait for green!");
    } else if (parts >= PARTS_TO_WIN - 1 && parts > 0) {
      this.setHud("hud-status", "One more part! Get to the garage!");
    } else {
      this.setHud("hud-status", "Find the car parts!");
    }
  }

  private setHud(id: string, text: string) {
    if (this.hudCache[id] === text) {
      return;
    }
    this.hudCache[id] = text;
    this.hudEls[id]?.setProperties({ text });
  }
}
