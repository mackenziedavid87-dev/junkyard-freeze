#!/usr/bin/env python3
# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""Generate public/audio/clank.wav — one soft metallic footstep clank.

The creatures in Junkyard Freeze are built from old car parts, so their
footsteps should sound like metal clanging with each step — a short
"clickety-clack", not a crash. One clank per stride, played through a
positional AudioSource on each creature, so it is louder up close and
fades with distance (and doubles as a warning that one is coming).

The sound itself is synthesised (same approach as scripts/make-ambient-
loop.py), so the template ships with no licensed audio: a handful of
inharmonic partials (a struck metal bar rings at non-harmonic ratios)
with fast exponential decays, plus a 12 ms noise burst at the onset for
the "clang" attack. Peak-normalised to a modest level — the game scales
it further by distance, so the file itself stays soft.

Usage:  python3 scripts/make-clank.py
"""

import math
import os
import random
import struct
import wave

SAMPLE_RATE = 22050
DURATION_SECONDS = 0.35
OUT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "public",
    "audio",
    "clank.wav",
)

# (frequency Hz, gain, decay rate per second) — a small struck-metal
# cluster: bright but not shrill, gone in ~0.3 s.
PARTIALS = [
    (587.0, 0.50, 95.0),
    (913.0, 0.38, 75.0),
    (1327.0, 0.30, 60.0),
    (1893.0, 0.20, 45.0),
    (2511.0, 0.12, 32.0),
]
# Onset noise burst: 12 ms of noise, gain 0.25, decaying fast.
NOISE_MS = 12
NOISE_GAIN = 0.25
NOISE_DECAY = 400.0
# Keep the file itself soft — the game scales volume by distance.
PEAK_TARGET = 0.55


def main():
    rng = random.Random(20261112)
    n = int(SAMPLE_RATE * DURATION_SECONDS)
    samples = [0.0] * n
    for i in range(n):
        t = i / SAMPLE_RATE
        value = 0.0
        for freq, gain, decay in PARTIALS:
            value += gain * math.exp(-decay * t) * math.sin(2.0 * math.pi * freq * t)
        if t < NOISE_MS / 1000.0:
            value += NOISE_GAIN * math.exp(-NOISE_DECAY * t) * (rng.random() * 2.0 - 1.0)
        samples[i] = value
    peak = max(abs(s) for s in samples) or 1.0
    scale = PEAK_TARGET / peak
    frames = b"".join(
        struct.pack("<h", max(-32768, min(32767, int(s * scale * 32767))))
        for s in samples
    )
    os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
    with wave.open(OUT_PATH, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(SAMPLE_RATE)
        wav.writeframes(frames)
    print(f"wrote {OUT_PATH} ({len(frames)} bytes, {DURATION_SECONDS}s)")


if __name__ == "__main__":
    main()
