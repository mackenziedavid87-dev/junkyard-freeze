# Junkyard Freeze — Build Guide (Round 3, 2026-11-12)

"Junkyard Freeze" — a single-player vertical slice for the Meta VR Start
Developer Competition 2026, built from Meta's official IWSDK Replit starter
(`@iwsdk/core`, WebXR). A junkyard with 28 old cars, a freeze gun, creatures
built from ratty car parts, 6 car parts to find and install in the garage,
and a drive-out win. Multiplayer is NOT built (stretch goal).

## What's in this build (round 3)

David's pacing decision (2026-11-12 morning): difficulty, not length. The
game was finishing in ~2–2.5 minutes, so the fix is a harder second half,
not a longer yard.

1. **Second creature.** Spawns at the far south-east corner (14, 11) once
   the 3rd of the 6 parts is installed (`SECOND_CREATURE_PARTS = 3` in
   `src/game-state.ts`). Same chase AI, speed formula (1.25 m/s + 0.12 per
   part installed), freeze/thaw rules, 0.8 m catch distance, and
   stuck/sidestep logic per creature. A catch by EITHER creature triggers
   the same ~2s auto-restart with a full reset (creature 2 hides again
   until 3 parts are installed). Freezing it pays 1 pt. Win stays 6 parts.
2. **Second creature's arms (only it gets arms).** Right arm: a wrench
   with a hammer on the end. Left arm: two wrenches. Fingers: little
   wrenches. They hang at its sides; see `../junkyard-freeze-round3-creature.png`
   (screenshot of creature 2 in the headset view).
3. **Drive-shaft neck on both creatures.** A short drive shaft between the
   body (motor) and the head, so the head sits just up over the body. The
   head/eyes were NOT lowered — eyes still sit above the car rooflines.
4. **Bigger creatures.** `CREATURE_SCALE` 1.3 → 1.4, about 1.9 m tall —
   clearly taller than the player. Speed, freeze times, catch distance,
   grace period, magazine rules, and point values unchanged. Obstacle
   clearance bumped slightly for the bigger body (`CAR_BLOCK_RADIUS`
   1.5 → 1.55 m, creature body radius 0.45 → 0.5 m); gaps between cars
   are still ~1.9 m wide.
5. **Creature footstep sounds.** A metallic "clickety-clack" clank per
   step — one clank per 0.55 m travelled (`CREATURE_STEP_LENGTH`), volume
   scaled by distance to the player (louder when close — a warning you
   can hear coming). Both creatures clank; the mix is soft. The sound is
   a short synthesized metallic clank (`public/audio/clank.wav`, generated
   by `scripts/make-clank.py`), played through a positional `AudioSource`
   on each creature, reusing the project's audio pipeline.

Unchanged rules: 6 parts (engine, wheel, door, battery, headlight,
steering wheel), win = install all 6; freeze = 1 pt, part = 2 pts,
upgrade = 5 pts; freeze 5s (Mk I) / 9s (Mk II); 2-shot magazine, 4s
recharge, 3s backfire self-freeze; 8s grace at run start; catch 0.8 m.

## Running it

```bash
export PATH=$HOME/node-v22.23.4-linux-x64/bin:$PATH   # on David's Acer, per Terminal
cd ~/junkyard-freeze-game
npm run dev:runtime        # plain Vite on http://localhost:5000
```

Use `npm run dev:runtime`, NOT `npm run dev` (the managed `iwsdk dev`
command hangs on the Acer). If a previous server is still running,
`npm run dev:down` first. The Playwright/Chromium error at startup is
harmless (Playwright doesn't support chromium on Debian 11). For the
headset the game needs a public https link (Cloudflare tunnel or GitHub
Pages — the tunnel link is temporary).

## Files that matter

- `src/index.ts` — junkyard scene, `makeCreature()` (neck, wrench arms),
  `makeStepAudio()`, asset manifest (incl. `clankSound`).
- `src/game-state.ts` — tuning: `CREATURE_SCALE = 1.4`,
  `CREATURE_SPAWN_2 = [14, 0, 11]`, `SECOND_CREATURE_PARTS = 3`,
  `CREATURE_STEP_LENGTH = 0.55`, `CAR_BLOCK_RADIUS = 1.55`,
  `PARTS_TO_WIN = 6`, `YARD_BOUNDS`, `CAR_SPOTS` (28 cars).
- `src/creature.ts` — chase AI, per-creature spawn/stuck/sidestep logic,
  footstep tracking (`playStep()`, distance-based, volume by proximity).
- `src/game.ts` — points, win/lose, auto-restart (~2s), `restart()`
  (creature 2 hides again), debug handle `window.__jf` (`state()`,
  `restart()`, `installPart(id)`, `shootCreature(i)`).
- `src/freeze-gun.ts` — trigger/click shooting; the click handler checks
  every creature; `Pressed` subscription is generic per creature.
- `scripts/make-clank.py` — regenerates `public/audio/clank.wav`
  (0.35 s, 22050 Hz mono, inharmonic metallic partials + noise burst).

## Verification (2026-11-12, headless probe, localhost:5000)

- `npm run typecheck` clean; `npm run build` (vite) clean (chunk-size
  warning only, pre-existing).
- Creature 2 spawns only at 3 parts installed, chases, steps track
  distance (20/21 steps over the probe run); freeze pays exactly +1
  (6 → 7 pts), re-freeze while frozen pays 0, thaws after 5s and resumes.
- Catch by creature 2 (0.5 m, creature 1 frozen 3.07 m away) →
  auto-restart ~2.1s later with a full reset (points 0, parts 0,
  creature 2 hidden again).
- Win at 6 parts: 0 → 12 pts, phase WON.
- No car clipping at the bigger size: closest approach 1.65 m / 1.67 m
  vs the 1.55 m block radius. No console errors, no failed requests.
- XR screenshot confirms the taller creature, eyes above the car
  rooflines, drive-shaft neck, and wrench arms.
- Footstep audibility in a real headset is NOT verified headless (no
  audio output in the probe) — the headset run is the check for how the
  clanks sound. `clank.wav` is bundled and serves HTTP 200.
- Emulator caveat: this sandbox's XR emulator stopped delivering
  trigger/select presses to the game (ray hover works; three input
  mechanisms tested, none produces `Pressed`). The game's trigger path
  is the standard SDK subscription, verified working in the real headset
  on 2026-11-11. Probe tip: `xr look-at` targets are XR-local
  (world minus player position), and calling the CLI directly
  (`node node_modules/@iwsdk/cli/bin/iwsdk.js xr ...`) is ~3.5× faster
  than through `npx`.

## Project house rules

See `AGENTS.md` in this folder: always run `npm run typecheck` before
testing; imports from `@iwsdk/core`, never from `'three'` directly; one
system per file; read the bundled skills under `.agents/skills/` before
that kind of work. `iwsdk.config.json` is the project authority.
