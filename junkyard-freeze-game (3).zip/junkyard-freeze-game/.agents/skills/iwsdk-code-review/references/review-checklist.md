<!-- Reference for the `iwsdk-code-review` skill. Work through this when
reviewing IWSDK application code. -->

# IWSDK Review Checklist

Twenty checks, ordered roughly by how often they catch something. Each gives
the pattern to flag and the correct form.

## Review Checklist

### 1. Feature Configuration (CRITICAL)

**This is the #1 cause of bugs in IWSDK projects.**

Check `World.create()` for feature misconfiguration:

```typescript
// ❌ CRITICAL BUG - Locomotion without collision geometry
World.create(container, {
  features: {
    locomotion: true, // Player will fall through the world!
  },
});

// ✅ CORRECT - Locomotion with proper environment
World.create(container, {
  features: {
    locomotion: true,
    physics: true, // Or scene has LocomotionEnvironment
  },
});
```

**What to check:**

- If `locomotion: true`, verify scene has `LocomotionEnvironment` component OR physics collision
- If `physics: true`, verify entities have `PhysicsBody` + `PhysicsShape` components
- If `grabbing: true`, verify entities have Grabbable components
- For AR (`SessionMode.ImmersiveAR`), ensure `locomotion: false`
- Features not used should be `false` to avoid overhead

### 2. Systems: No Entity Arrays

Systems should NOT store entity arrays. Use queries instead.

```typescript
// ❌ BAD - Storing entity references
class MySystem extends createSystem({...}) {
  private myEntities: Entity[] = [];  // DON'T DO THIS

  init() {
    this.queries.items.subscribe('qualify', (entity) => {
      this.myEntities.push(entity);  // BAD
    });
  }
}

// ✅ GOOD - Use queries
class MySystem extends createSystem({
  items: { required: [MyComponent] }
}) {
  update() {
    for (const entity of this.queries.items.entities) {
      // Query always has current entities
    }
  }
}
```

### 3. No Allocations in update()

Hot paths (`update()`) should not allocate memory.

```typescript
// ❌ BAD - Allocates every frame
update() {
  const tempVec = new Vector3();  // Creates garbage every frame
  entity.object3D.getWorldPosition(tempVec);
}

// ✅ GOOD - Scratch variables in init() or as class properties
private tempVec!: Vector3;

init() {
  this.tempVec = new Vector3();
}

update() {
  entity.object3D.getWorldPosition(this.tempVec);
}
```

**What to look for in update():**

- `new Vector3()`, `new Quaternion()`, `new Matrix4()`, `new Euler()`
- Array literals `[]` or object literals `{}`
- `.clone()` calls
- String concatenation for keys

### 4. Use Reactive Patterns (subscribe)

Use query subscriptions for one-time operations, not polling in update().

```typescript
// ❌ BAD - Polling in update
update() {
  this.queries.items.entities.forEach(entity => {
    if (entity.hasComponent(Pressed)) {  // Checking every frame
      this.handlePress(entity);
    }
  });
}

// ✅ GOOD - Subscribe to combined query
class MySystem extends createSystem({
  pressedItems: { required: [MyComponent, Pressed] }
}) {
  init() {
    this.queries.pressedItems.subscribe('qualify', (entity) => {
      this.handlePress(entity);  // Called once when pressed
    });
  }
}
```

### 5. Use VisibilityState Correctly

React to XR state changes properly.

```typescript
// ✅ GOOD - Subscribe to visibility changes
init() {
  this.world.visibilityState.subscribe((state) => {
    if (state === VisibilityState.Visible) {
      // In XR
    } else if (state === VisibilityState.NonImmersive) {
      // In browser (2D)
    }
  });
}
```

### 6. Cleanup Subscriptions

Signal subscriptions must be cleaned up to prevent memory leaks.

```typescript
// ❌ BAD - No cleanup
init() {
  this.world.visibilityState.subscribe((state) => {
    // Never unsubscribed!
  });
}

// ✅ GOOD - Register cleanup
init() {
  this.cleanupFuncs.push(
    this.world.visibilityState.subscribe((state) => {
      // Will be cleaned up when system is destroyed
    })
  );
}
```

### 7. Component Types

Use proper types, avoid `Types.Object`.

```typescript
// ❌ BAD - Using Object type
const MyComponent = createComponent('MyComponent', {
  data: { type: Types.Object, default: {} }, // Not optimized
});

// ✅ GOOD - Use specific types
const MyComponent = createComponent('MyComponent', {
  speed: { type: Types.Float32, default: 1.0 },
  position: { type: Types.Vec3, default: [0, 0, 0] },
  color: { type: Types.Color, default: [1, 1, 1, 1] }, // RGBA
});
```

### 8. PhysicsBody vs PhysicsShape

These are separate components with different purposes.

```typescript
// PhysicsBody = motion properties
entity.addComponent(PhysicsBody, {
  state: PhysicsState.Dynamic, // or Static, Kinematic
  linearDamping: 0.5,
  gravityFactor: 1.0,
});

// PhysicsShape = collision shape + material
entity.addComponent(PhysicsShape, {
  shape: PhysicsShapeType.Box,
  density: 1.0,
  restitution: 0.5, // Bounciness
  friction: 0.3,
});
```

### 9. Input Handling

Check for proper gamepad/input access.

```typescript
// ✅ GOOD - Safe input access with optional chaining
update() {
  const leftGamepad = this.input.gamepads.left;
  const triggerPressed = leftGamepad?.getButtonDown(InputComponent.Trigger) ?? false;
}
```

### 10. Audio Configuration

Check PlaybackMode usage.

```typescript
// Available PlaybackMode values:
PlaybackMode.Restart; // Stop current, restart
PlaybackMode.Overlap; // Play new instance
PlaybackMode.Ignore; // Ignore if playing
PlaybackMode.FadeRestart; // Fade out, start new
```

### 11. Three.js Import Check (CRITICAL)

Check for direct imports from 'three' package - should use @iwsdk/core instead.

```typescript
// ❌ BAD - causes duplicate Three.js instances
import { Vector3 } from 'three';
import * as THREE from 'three';

// ✅ GOOD
import { Vector3, Mesh, MeshStandardMaterial } from '@iwsdk/core';
```

**Exception:** GLTF loader types can come from three/addons:

```typescript
import type { GLTF } from 'three/addons/loaders/GLTFLoader.js';
```

### 12. Component Size Check

Flag components with more than 10 fields - consider splitting into focused components.

```typescript
// ❌ BAD - Fat component with too many fields
const Vehicle = createComponent('Vehicle', {
  position: ..., orientation: ..., speed: ...,
  engineRPM: ..., gear: ..., throttle: ..., steering: ...,
  fuel: ..., health: ..., score: ..., // Too many!
});

// ✅ GOOD - Split into focused components
const VehiclePhysics = createComponent('VehiclePhysics', { position: ..., speed: ... });
const VehicleEngine = createComponent('VehicleEngine', { rpm: ..., gear: ... });
```

### 13. Signal Access in update()

Check for `.value` access on signals in update() - should use `.peek()` instead.

```typescript
// ❌ BAD - creates subscription overhead every frame
update() {
  const rate = this.config.tickRate.value;
}

// ✅ GOOD - peek() reads without subscription
update() {
  const rate = this.config.tickRate.peek();
}
```

### 14. Handle Existing Entities in init()

Systems should iterate existing entities in init(), not just subscribe to qualify:

```typescript
// ❌ BAD - Misses entities that exist before system starts
init() {
  this.queries.items.subscribe('qualify', (entity) => {
    this.setupEntity(entity);
  });
}

// ✅ GOOD - Handle existing AND new entities
init() {
  // Subscribe for NEW entities
  this.queries.items.subscribe('qualify', (entity) => {
    this.setupEntity(entity);
  });

  // ALSO handle existing entities
  for (const entity of this.queries.items.entities) {
    this.setupEntity(entity);
  }
}
```

### 15. Direct asset loaders instead of AssetManager

Flag: `new GLTFLoader()`, `new OBJLoader()`, `new TextureLoader()` used directly.

```typescript
// ❌ BAD - bypasses DRACO/KTX2 setup, no caching, no de-duplication
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
const loader = new GLTFLoader();
const gltf = await loader.loadAsync(url);

// ✅ GOOD - use AssetManager
const gltf = await AssetManager.loadGLTF(url, 'myModel');
// or declare in World.create({ assets: { myModel: { url, type: AssetType.GLTF } } })
```

### 16. Raw scene.add() instead of createTransformEntity

Flag: `scene.add(...)` or `world.scene.add(...)` or `this.scene.add(...)` for adding content.

```typescript
// ❌ BAD - bypasses ECS, no Transform component, no level lifecycle
this.scene.add(mesh);

// ✅ GOOD - proper entity creation
world.createTransformEntity(mesh, parentEntity);
```

### 17. Manual Raycaster instead of Interactable

Flag: `new THREE.Raycaster()` or `new Raycaster()` for interaction detection.

```typescript
// ❌ BAD - no BVH acceleration, doesn't work in XR, no pointer events
const raycaster = new Raycaster();

// ✅ GOOD - add Interactable component, query Hovered/Pressed in system
entity.addComponent(Interactable);
```

### 18. Environment components on wrong entity

Flag: `DomeGradient`/`DomeTexture`/`IBLGradient`/`IBLTexture` added to entities that don't have `LevelRoot`.

```typescript
// ❌ BAD - Environment components only work on the level root entity
someEntity.addComponent(DomeGradient, { ... });

// ✅ GOOD - Add to the level root
const root = world.activeLevel.value;
root.addComponent(DomeGradient, { ... });
```

### 19. Missing `_needsUpdate` on environment changes

Flag: Setting properties on `DomeGradient`/`DomeTexture`/`IBLGradient`/`IBLTexture` without setting `_needsUpdate: true`.

```typescript
// ❌ BAD - Changes are silently ignored
root.setValue(DomeGradient, 'sky', [0.1, 0.2, 0.8, 1.0]);

// ✅ GOOD - Always set _needsUpdate after property changes
root.setValue(DomeGradient, 'sky', [0.1, 0.2, 0.8, 1.0]);
root.setValue(DomeGradient, '_needsUpdate', true);
```

### 20. Using `destroy()` instead of `dispose()` for GPU objects

Flag: `entity.destroy()` on entities with meshes/materials.

```typescript
// ❌ BAD - GPU memory for geometry/materials/textures is leaked
entity.destroy();

// ✅ GOOD - Use dispose() for proper GPU cleanup
entity.dispose();
```

---
